/**
 * This file was automatically created by bin/libnapc/preprocess/steps/4.createTestsHeaderAndSourceFile.php
 */
#include <napc.h>
void PV_napc_aes__testCase1(void);
void PV_napc_dns__testCase2(void);
void PV_napc_dns__testCase3(void);
void PV_napc_dns__testCase4(void);
void PV_napc_dns__testCase5(void);
void PV_napc_dns__testCase6(void);
void PV_napc_eth__testCase7(void);
void PV_napc_hmac__testCase8(void);
void PV_napc_hmac__testCase9(void);
void PV_napc_misc__testCase10(void);
void PV_napc_misc__testCase11(void);
void PV_napc_misc__testCase12(void);
void PV_napc_parser__testCase13(void);
void PV_napc_parser__testCase14(void);
void PV_napc_parser__testCase15(void);
void PV_napc_parser__testCase16(void);
void PV_napc_parser__testCase17(void);
void PV_napc_parser__testCase18(void);
void PV_napc_parser__testCase19(void);
void PV_napc_parser__testCase20(void);
void PV_napc_parser__testCase21(void);
void PV_napc_parser__testCase22(void);
void PV_napc_parser__testCase23(void);
void PV_napc_parser__testCase24(void);
void PV_napc_parser__testCase25(void);
void PV_napc_parser__testCase26(void);
void PV_napc_parser__testCase27(void);
void PV_napc_parser__testCase28(void);
void PV_napc_parser__testCase29(void);
void PV_napc_parser__testCase30(void);
void PV_napc_parser__testCase31(void);
void PV_napc_parser__testCase32(void);
void PV_napc_parser__testCase33(void);
void PV_napc_parser__testCase34(void);
void PV_napc_parser__testCase35(void);
void PV_napc_parser__testCase36(void);
void PV_napc_parser__testCase37(void);
void PV_napc_parser__testCase38(void);
void PV_napc_parser__testCase39(void);
void PV_napc_parser__testCase40(void);
void PV_napc_parser__testCase41(void);
void PV_napc_parser__testCase42(void);
void PV_napc_parser__testCase43(void);
void PV_napc_parser__testCase44(void);
void PV_napc_parser__testCase45(void);
void PV_napc_parser__testCase46(void);
void PV_napc_parser__testCase47(void);
void PV_napc_parser__testCase48(void);
void PV_napc_parser__testCase49(void);
void PV_napc_parser__testCase50(void);
void PV_napc_parser__testCase51(void);
void PV_napc_parser__testCase52(void);
void PV_napc_parser__testCase53(void);
void PV_napc_parser__testCase54(void);
void PV_napc_parser__testCase55(void);
void PV_napc_parser__testCase56(void);
void PV_napc_parser__testCase57(void);
void PV_napc_parser__testCase58(void);
void PV_napc_parser__testCase59(void);
void PV_napc_pool__testCase60(void);
void PV_napc_reader__testCase61(void);
void PV_napc_reader__testCase62(void);
void PV_napc_reader__testCase63(void);
void PV_napc_reader__testCase64(void);
void PV_napc_reader__testCase65(void);
void PV_napc_reader__testCase66(void);
void PV_napc_reader__testCase67(void);
void PV_napc_reader__testCase68(void);
void PV_napc_reader__testCase69(void);
void PV_napc_reader__testCase70(void);
void PV_napc_reader__testCase71(void);
void PV_napc_reader__testCase72(void);
void PV_napc_reader__testCase73(void);
void PV_napc_reader__testCase74(void);
void PV_napc_reader__testCase75(void);
void PV_napc_reader__testCase76(void);
void PV_napc_reader__testCase77(void);
void PV_napc_reader__testCase78(void);
void PV_napc_reader__testCase79(void);
void PV_napc_reader__testCase80(void);
void PV_napc_reader__testCase81(void);
void PV_napc_ringbuffer__testCase82(void);
void PV_napc_ringbuffer__testCase83(void);
void PV_napc_ringbuffer__testCase84(void);
void PV_napc_ringbuffer__testCase85(void);
void PV_napc_ringbuffer__testCase86(void);
void PV_napc_ringbuffer__testCase87(void);
void PV_napc_ringbuffer__testCase88(void);
void PV_napc_ringbuffer__testCase89(void);
void PV_napc_ringbuffer__testCase90(void);
void PV_napc_ringbuffer__testCase91(void);
void PV_napc_ringbuffer__testCase92(void);
void PV_napc_ringbuffer__testCase93(void);
void PV_napc_sha__testCase94(void);
void PV_napc_sha__testCase95(void);
void PV_napc_sha__testCase96(void);
void PV_napc_writer__testCase97(void);
void PV_napc_writer__testCase98(void);
void PV_napc_writer__testCase99(void);
void PV_napc_writer__testCase100(void);
void PV_napc_writer__testCase101(void);
void PV_napc_writer__testCase102(void);
void PV_napc_writer__testCase103(void);
void PV_napc_writer__testCase104(void);
void PV_napc_writer__testCase105(void);
void PV_napc_writer__testCase106(void);
void napc_aes__runTests(void) {
    PV_napc_aes__testCase1(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All aes tests have passed!\n");
    napc_mute();
}
void napc_dns__runTests(void) {
    PV_napc_dns__testCase2(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_dns__testCase3(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_dns__testCase4(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_dns__testCase5(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_dns__testCase6(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All dns tests have passed!\n");
    napc_mute();
}
void napc_eth__runTests(void) {
    PV_napc_eth__testCase7(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All eth tests have passed!\n");
    napc_mute();
}
void napc_hmac__runTests(void) {
    PV_napc_hmac__testCase8(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_hmac__testCase9(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All hmac tests have passed!\n");
    napc_mute();
}
void napc_misc__runTests(void) {
    PV_napc_misc__testCase10(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_misc__testCase11(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_misc__testCase12(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All misc tests have passed!\n");
    napc_mute();
}
void napc_parser__runTests(void) {
    PV_napc_parser__testCase13(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase14(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase15(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase16(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase17(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase18(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase19(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase20(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase21(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase22(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase23(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase24(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase25(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase26(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase27(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase28(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase29(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase30(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase31(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase32(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase33(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase34(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase35(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase36(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase37(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase38(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase39(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase40(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase41(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase42(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase43(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase44(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase45(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase46(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase47(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase48(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase49(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase50(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase51(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase52(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase53(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase54(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase55(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase56(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase57(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase58(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_parser__testCase59(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All parser tests have passed!\n");
    napc_mute();
}
void napc_pool__runTests(void) {
    PV_napc_pool__testCase60(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All pool tests have passed!\n");
    napc_mute();
}
void napc_reader__runTests(void) {
    PV_napc_reader__testCase61(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase62(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase63(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase64(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase65(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase66(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase67(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase68(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase69(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase70(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase71(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase72(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase73(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase74(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase75(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase76(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase77(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase78(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase79(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase80(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_reader__testCase81(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All reader tests have passed!\n");
    napc_mute();
}
void napc_ringbuffer__runTests(void) {
    PV_napc_ringbuffer__testCase82(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase83(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase84(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase85(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase86(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase87(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase88(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase89(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase90(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase91(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase92(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_ringbuffer__testCase93(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All ring-buffer tests have passed!\n");
    napc_mute();
}
void napc_sha__runTests(void) {
    PV_napc_sha__testCase94(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_sha__testCase95(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_sha__testCase96(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All sha tests have passed!\n");
    napc_mute();
}
void napc_writer__runTests(void) {
    PV_napc_writer__testCase97(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase98(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase99(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase100(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase101(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase102(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase103(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase104(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase105(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    PV_napc_writer__testCase106(); napc_unmute(); napc_puts("passed!\n"); napc_mute();
    napc_unmute();
    napc_puts("All writer tests have passed!\n");
    napc_mute();
}
void napc_runAllTests(void) {
    napc_aes__runTests();
    napc_dns__runTests();
    napc_eth__runTests();
    napc_hmac__runTests();
    napc_misc__runTests();
    napc_parser__runTests();
    napc_pool__runTests();
    napc_reader__runTests();
    napc_ringbuffer__runTests();
    napc_sha__runTests();
    napc_writer__runTests();
    napc_unmute();
    napc_puts("\n\nAll tests successfully passed! :-)\n\n");
}
