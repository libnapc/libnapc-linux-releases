#!/bin/bash -euf
printf "compiling 'build/__tests__/__tests__.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/__tests__.c' -c -o objects/2442eccd1145d677675793958d27da2b.o
printf "ok\n"
printf "compiling 'build/__tests__/aes/aes_basic.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/aes/aes_basic.c' -c -o objects/e752f083b11788676c545db7caa46ac6.o
printf "ok\n"
printf "compiling 'build/__tests__/dns/dns_parse_header.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/dns/dns_parse_header.c' -c -o objects/0326ddded5f8968abe2215a1cc6d2770.o
printf "ok\n"
printf "compiling 'build/__tests__/dns/dns_parse_request_A.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/dns/dns_parse_request_A.c' -c -o objects/8a3b5fef4fc4433289147d70bb786867.o
printf "ok\n"
printf "compiling 'build/__tests__/dns/dns_parse_request_AAAA.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/dns/dns_parse_request_AAAA.c' -c -o objects/daca8835d8ecf252c085c29738546c14.o
printf "ok\n"
printf "compiling 'build/__tests__/dns/dns_parse_response_A.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/dns/dns_parse_response_A.c' -c -o objects/c865ec75c45026b8fecb03e2c9e3d141.o
printf "ok\n"
printf "compiling 'build/__tests__/dns/dns_parse_response_AAAA.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/dns/dns_parse_response_AAAA.c' -c -o objects/afc216680732e22ee1112cfd7e8cbd85.o
printf "ok\n"
printf "compiling 'build/__tests__/eth/eth_broadcast_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/eth/eth_broadcast_address.c' -c -o objects/f7faaad1b9c69c0c2be741e73915b718.o
printf "ok\n"
printf "compiling 'build/__tests__/hmac/hmac_calculate.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/hmac/hmac_calculate.c' -c -o objects/f5c602f40dbbf3af68c1f8206ffefc34.o
printf "ok\n"
printf "compiling 'build/__tests__/hmac/hmac_verify.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/hmac/hmac_verify.c' -c -o objects/45b889966d1ff63dfe3d74cf8c5fa542.o
printf "ok\n"
printf "compiling 'build/__tests__/misc/misc_chunks_impartial.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/misc/misc_chunks_impartial.c' -c -o objects/a429de2814ac72e94c5f9ffc64115e7c.o
printf "ok\n"
printf "compiling 'build/__tests__/misc/misc_memory_fence.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/misc/misc_memory_fence.c' -c -o objects/bffee34a94bff1cba15594a9decfa8d3.o
printf "ok\n"
printf "compiling 'build/__tests__/misc/misc_shift_array_right.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/misc/misc_shift_array_right.c' -c -o objects/55060ab01491d73cdc9f88f1e95472ae.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_boolean.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_boolean.c' -c -o objects/d09c9556aaa1c1ba713e1fe06d592f69.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_decimal_number_u16.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_decimal_number_u16.c' -c -o objects/d24855ccd2165c775d617dd93d0d6a57.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_decimal_number_u32.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_decimal_number_u32.c' -c -o objects/4492044b4870c5bab7984dd6b7f79460.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_decimal_number_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_decimal_number_u8.c' -c -o objects/9b89903e92d9eef7db1c0329e5c81d27.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_hex_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_hex_string.c' -c -o objects/ff566ede9a71782a284604f5e8116195.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_hexadecimal_number_u16.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_hexadecimal_number_u16.c' -c -o objects/5bb42028c586a7691ea1ea65c95f56d0.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_hexadecimal_number_u32.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_hexadecimal_number_u32.c' -c -o objects/3d4c049afe34f0c6b15e13ccd82feccf.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_hexadecimal_number_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_hexadecimal_number_u8.c' -c -o objects/2e64a743fb6ec0111cc0329f4f23416a.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_ipv4_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_ipv4_address.c' -c -o objects/41fc4731b4ab11b560f26c97e1c89720.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_key_value.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_key_value.c' -c -o objects/b0da0b82792bf36e10002fbaa38f319f.o
printf "ok\n"
printf "compiling 'build/__tests__/parser/parser_parse_mac_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/parser/parser_parse_mac_address.c' -c -o objects/fdc1252d15cbae154d3151efc10bd699.o
printf "ok\n"
printf "compiling 'build/__tests__/pool/pool_basic.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/pool/pool_basic.c' -c -o objects/eae15a7ee2eaf610a38d4a6775d5b726.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_char.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_char.c' -c -o objects/cd631b43ab1ab5c249c88216cbe3e3d3.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_get_current_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_get_current_address.c' -c -o objects/0a60852bef591b7c98cb01af062035a1.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_get_end_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_get_end_address.c' -c -o objects/4180a94a54b5632b6f08a021256c65c5.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_get_start_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_get_start_address.c' -c -o objects/ce7f8867b74fbc3e115d8a764ae562df.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_line.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_line.c' -c -o objects/a0813717abfb259bc27f69fd32927db1.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_string.c' -c -o objects/9d6ef5e72ed070ef55d71e6a7b687281.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_u16be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_u16be.c' -c -o objects/ed407f34f600172b0ce13b8b662277e5.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_u32be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_u32be.c' -c -o objects/683583f3e9049120a4ee8febcfc96888.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_u8.c' -c -o objects/b67dd83bdb30d6ddad90f82c58a7c90d.o
printf "ok\n"
printf "compiling 'build/__tests__/reader/reader_u8_array.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/reader/reader_u8_array.c' -c -o objects/72cce4224962949c7d6e53e0120235a4.o
printf "ok\n"
printf "compiling 'build/__tests__/sha/sha_basic.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/sha/sha_basic.c' -c -o objects/1f23b5299c3d45148ffe3d66b9ff8d70.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_char.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_char.c' -c -o objects/b57a07d4de5342b3df5d09459fbe773a.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_get_current_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_get_current_address.c' -c -o objects/ba89435d1592a2aff798092f278d1d6f.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_get_end_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_get_end_address.c' -c -o objects/b03aaefb885f964fa5924a931b099b2f.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_get_start_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_get_start_address.c' -c -o objects/6217e167dc5a37273bbd9527143ac791.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_move_current_offset_by_amount.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_move_current_offset_by_amount.c' -c -o objects/e579f4e920631ea336f88b50a9b4ab1d.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_string.c' -c -o objects/6469d6a9fd506beb2cadec9cd3cc9797.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_string_format.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_string_format.c' -c -o objects/d07892d76548c6d681a40cee3fe22670.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_u16be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_u16be.c' -c -o objects/9055ec7237e079ddd790594966788daa.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_u32be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_u32be.c' -c -o objects/1aab434292b5ad1be0ba2b16d8db2243.o
printf "ok\n"
printf "compiling 'build/__tests__/writer/writer_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/__tests__/writer/writer_u8.c' -c -o objects/53936bc1778d21ecafe729c5fcb0ed8d.o
printf "ok\n"
printf "compiling 'build/boot/linux.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/boot/linux.c' -c -o objects/f8c3acd65336d3ddce727054d47b60db.o
printf "ok\n"
printf "compiling 'build/boot_functions.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/boot_functions.c' -c -o objects/d0370ed22fb4fd89a14904d581e31bbc.o
printf "ok\n"
printf "compiling 'build/hw.module/env/public/is_ethernet_available.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/env/public/is_ethernet_available.c' -c -o objects/fea6bb9a8f4d147da34c7ec5e067e86a.o
printf "ok\n"
printf "compiling 'build/hw.module/env/public/is_file_system_available.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/env/public/is_file_system_available.c' -c -o objects/87004529a13ea86ea6852eaf1b74f0b4.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_eth_getLinkStatus.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_eth_getLinkStatus.c' -c -o objects/63d13efb9d6b48051b4df9123b134c9d.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setGatewayAddress.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setGatewayAddress.c' -c -o objects/8b89df4f76e26639a50cfc874ac01bfe.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setIPAddress.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setIPAddress.c' -c -o objects/6a9faa9495ab9813bbd7375f4e1e3f9b.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setMACAddress.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setMACAddress.c' -c -o objects/23faba048e211e96cd74e3e2ffc8cc0e.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setSubnetMask.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_eth_setSubnetMask.c' -c -o objects/6d6d6d1e6208670ec4bff1bb83263b1f.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/HAL/linux/HAL_napc_initEthernet.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/HAL/linux/HAL_napc_initEthernet.c' -c -o objects/56d3758c3eb4cafc0ad16c689a593bea.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/_private/_assert_initialized.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/_private/_assert_initialized.c' -c -o objects/a386e4116521362a9bd7874d366061a5.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/_private/_vars.c' -c -o objects/13050139e00b931aff45cbea19336cce.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/calculate_broadcast_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/calculate_broadcast_address.c' -c -o objects/1c6b438775c3fe319d616cf946af2e5d.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/get_link_status.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/get_link_status.c' -c -o objects/3d73b4c42932403efb71cc97d85b71b4.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/set_gateway_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/set_gateway_address.c' -c -o objects/dd9d6e2d97724882e7ffd4450f1ecf4d.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/set_ip_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/set_ip_address.c' -c -o objects/106739e0fe708e7aa2bc5bf8df43491b.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/set_mac_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/set_mac_address.c' -c -o objects/52058a804744f49e06b954d230641986.o
printf "ok\n"
printf "compiling 'build/hw.module/eth/public/set_subnet_mask.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/eth/public/set_subnet_mask.c' -c -o objects/ac719711a7298b36afcd58a4141e37c3.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_File_close.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_File_close.c' -c -o objects/f2209c36a39f6af6109ae59c0ff87cb7.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_File_getSize.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_File_getSize.c' -c -o objects/dd9b1c434cc1e804774aefd61ffd5109.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_File_open.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_File_open.c' -c -o objects/b42c3990389f1af72ceaef5a74db5833.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_File_read.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_File_read.c' -c -o objects/1c4e7b3a1a1b31cb2831f65fec430ec0.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_File_write.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_File_write.c' -c -o objects/8d9df0e1e6e6b0f4ae1c0cccd29a604b.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_initFileSystem.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_initFileSystem.c' -c -o objects/73432abbd59f730bbd50594ac83c6100.o
printf "ok\n"
printf "compiling 'build/hw.module/file/HAL/linux/HAL_napc_initFileSystemHandlesPool.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/HAL/linux/HAL_napc_initFileSystemHandlesPool.c' -c -o objects/1ddf90221f2f954620811da65dfe477d.o
printf "ok\n"
printf "compiling 'build/hw.module/file/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/_private/_vars.c' -c -o objects/b72d3240003d4feb9cda89b81afa0fb0.o
printf "ok\n"
printf "compiling 'build/hw.module/file/public/close.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/public/close.c' -c -o objects/9972aa83789ab778992d3a0a33acd06c.o
printf "ok\n"
printf "compiling 'build/hw.module/file/public/get_size.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/public/get_size.c' -c -o objects/828cd3e7ab4e1425daf7c4bb03d79008.o
printf "ok\n"
printf "compiling 'build/hw.module/file/public/open.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/public/open.c' -c -o objects/6175a14739dbe0c140f667cd2667a5af.o
printf "ok\n"
printf "compiling 'build/hw.module/file/public/read.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/public/read.c' -c -o objects/0824d408fb7bb8da3543c4465c859320.o
printf "ok\n"
printf "compiling 'build/hw.module/file/public/write.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/file/public/write.c' -c -o objects/aba538fddcfc56b3a01cb1c5a0d20af7.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/_private/_read_file_chunk.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/_private/_read_file_chunk.c' -c -o objects/d754ea6e5b2bc8fb52013d0829345597.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/_private/_write_file_chunk.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/_private/_write_file_chunk.c' -c -o objects/becb442a366cb2e34a8e305d79e0ea4a.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/public/read_file.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/public/read_file.c' -c -o objects/3e669a18d377968ffd144ca4b438483b.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/public/read_file_c_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/public/read_file_c_string.c' -c -o objects/f29937a7e454de91fa1ed6dc7911f198.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/public/write_file.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/public/write_file.c' -c -o objects/fbd6478c0a016d326a7cf102f39f32e1.o
printf "ok\n"
printf "compiling 'build/hw.module/fs/public/write_file_c_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/fs/public/write_file_c_string.c' -c -o objects/34f38fe4b23911dfa222b5ed0ebfc05e.o
printf "ok\n"
printf "compiling 'build/hw.module/platform/linux/napc_linux__bindSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/platform/linux/napc_linux__bindSocket.c' -c -o objects/d69bacc17ec109a10e7255484e4a1c68.o
printf "ok\n"
printf "compiling 'build/hw.module/platform/linux/napc_linux__createAddressStruct.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/platform/linux/napc_linux__createAddressStruct.c' -c -o objects/227d83453fd8c4182f424549c44a662e.o
printf "ok\n"
printf "compiling 'build/hw.module/platform/linux/napc_linux__createUDPSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/platform/linux/napc_linux__createUDPSocket.c' -c -o objects/079998410e9228f4bb4253f30f47b5f4.o
printf "ok\n"
printf "compiling 'build/hw.module/platform/linux/napc_linux__readFromUDPSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/platform/linux/napc_linux__readFromUDPSocket.c' -c -o objects/b3c484fa445a00dd7537afe644224ee5.o
printf "ok\n"
printf "compiling 'build/hw.module/platform/linux/napc_linux__writeToUDPSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/platform/linux/napc_linux__writeToUDPSocket.c' -c -o objects/e77aaf3b61cb8f9aea68b079440af456.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_closeSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_closeSocket.c' -c -o objects/dfeeadc59f316d1313341c8de3d58960.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_createSocket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_createSocket.c' -c -o objects/71039262cff6d07e542f195b15d29463.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_initSocketPool.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_initSocketPool.c' -c -o objects/a8a8131445565ea163c1286b6446b389.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_receive.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_receive.c' -c -o objects/bbf550bec24d12e7500fc227ad8f6783.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_send.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/HAL/linux/HAL_napc_UDP_send.c' -c -o objects/5e1aa042c42336aeeff4cca5ace09b4c.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/_private/_log_message.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/_private/_log_message.c' -c -o objects/18c1a3b8bc6d1c1d813a3d4b21de5c7f.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/_private/_vars.c' -c -o objects/00ad3f6a7308064cc17fffd92796db38.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/close_socket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/close_socket.c' -c -o objects/62b7257abf982e1eb1d0dab862ee473e.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/create_socket.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/create_socket.c' -c -o objects/4a96d6d77ebb28f07551d102d6e8e54d.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/get_num_open_sockets.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/get_num_open_sockets.c' -c -o objects/9774d0cff7bf375d44ca812968b90667.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/receive.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/receive.c' -c -o objects/5fff8b5c2f0186ed4694f014e26e9946.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/send.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/send.c' -c -o objects/6f6c51151fc6b1f1395aed2160014606.o
printf "ok\n"
printf "compiling 'build/hw.module/udp/public/send_silent.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/hw.module/udp/public/send_silent.c' -c -o objects/d349c4d3763ac6cba7f15a559dd0fe81.o
printf "ok\n"
printf "compiling 'build/module/aes/_private/_tinyaes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/aes/_private/_tinyaes.c' -c -o objects/9ffed193b3cac07cfc382d15e7dc2317.o
printf "ok\n"
printf "compiling 'build/module/aes/public/decrypt.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/aes/public/decrypt.c' -c -o objects/73fc0c161a246e6b633ce2d1e02f64e0.o
printf "ok\n"
printf "compiling 'build/module/aes/public/encrypt.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/aes/public/encrypt.c' -c -o objects/fcef3902df2e66dc5d7fa2b06058d09d.o
printf "ok\n"
printf "compiling 'build/module/app/public/loop.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/app/public/loop.c' -c -o objects/1273795adf70565b19c50b24fd60420a.o
printf "ok\n"
printf "compiling 'build/module/app/public/setup.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/app/public/setup.c' -c -o objects/671db48d9703cb8dfa445d98718af770.o
printf "ok\n"
printf "compiling 'build/module/buffer/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/buffer/public/create.c' -c -o objects/b8a9c94730bd50436dc83dc9084aa186.o
printf "ok\n"
printf "compiling 'build/module/buffer/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/buffer/public/init.c' -c -o objects/6b08075011d299f37c876805c1087d2c.o
printf "ok\n"
printf "compiling 'build/module/dns/_private/_dn_expand.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/_private/_dn_expand.c' -c -o objects/a6e83c8bb96dc8b2081d308bc44bcac8.o
printf "ok\n"
printf "compiling 'build/module/dns/_private/_parse_answer_section.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/_private/_parse_answer_section.c' -c -o objects/6263c76d0f1ec1f48add149854c2f38c.o
printf "ok\n"
printf "compiling 'build/module/dns/_private/_parse_query_section.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/_private/_parse_query_section.c' -c -o objects/4d1ae1e153a98f5ec269435532325874.o
printf "ok\n"
printf "compiling 'build/module/dns/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/_private/_vars.c' -c -o objects/d1c2692e4af84cb115d4dea9c76c3206.o
printf "ok\n"
printf "compiling 'build/module/dns/public/parse_header.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/public/parse_header.c' -c -o objects/5830e0989122c8a1c2c18fb7f79e8eae.o
printf "ok\n"
printf "compiling 'build/module/dns/public/parse_request.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/public/parse_request.c' -c -o objects/49d9298df5bc7bcab848d5b8ea04fec2.o
printf "ok\n"
printf "compiling 'build/module/dns/public/parse_response.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/dns/public/parse_response.c' -c -o objects/839c59de9d073f3dbe5391c3a21f6a24.o
printf "ok\n"
printf "compiling 'build/module/hmac/_private/h5p9sl/_hmac-sha256.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/hmac/_private/h5p9sl/_hmac-sha256.c' -c -o objects/dabf2e62e281fc65db5f698682456694.o
printf "ok\n"
printf "compiling 'build/module/hmac/_private/h5p9sl/_sha256.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/hmac/_private/h5p9sl/_sha256.c' -c -o objects/4d382bd04f921c21578e0b7603086fb3.o
printf "ok\n"
printf "compiling 'build/module/hmac/public/calculate.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/hmac/public/calculate.c' -c -o objects/c4e645a8c5ac9569ad77cb5f6ee7f106.o
printf "ok\n"
printf "compiling 'build/module/hmac/public/verify.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/hmac/public/verify.c' -c -o objects/7f2402bec86966006b3fda66047bd3af.o
printf "ok\n"
printf "compiling 'build/module/ipv4participant/public/copy.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/ipv4participant/public/copy.c' -c -o objects/9d1df0ffa3fd537491afe94ce007478e.o
printf "ok\n"
printf "compiling 'build/module/ipv4participant/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/ipv4participant/public/create.c' -c -o objects/0b7e6535feab2fd6c7d57012e571aee7.o
printf "ok\n"
printf "compiling 'build/module/ipv4participant/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/ipv4participant/public/init.c' -c -o objects/381f0b7f858a86226f2ef87e23db39d2.o
printf "ok\n"
printf "compiling 'build/module/misc/public/chunked_operation.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/misc/public/chunked_operation.c' -c -o objects/d0fd1f12e03b36eec1e025d82f6c8b6c.o
printf "ok\n"
printf "compiling 'build/module/misc/public/print_hex_array.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/misc/public/print_hex_array.c' -c -o objects/a83a679a0448a10971bebc5265099c96.o
printf "ok\n"
printf "compiling 'build/module/misc/public/set_memory_fence_bytes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/misc/public/set_memory_fence_bytes.c' -c -o objects/215853900eab938cfe036a27b484ebf3.o
printf "ok\n"
printf "compiling 'build/module/misc/public/shift_array_right.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/misc/public/shift_array_right.c' -c -o objects/32adacb67dd4e3c7a339d131a379c12f.o
printf "ok\n"
printf "compiling 'build/module/misc/public/verify_memory_fence_bytes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/misc/public/verify_memory_fence_bytes.c' -c -o objects/3b520a398fadd33d3376a8b83e395b6c.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/create.c' -c -o objects/7f28d30e8a31784801fdd7622b250b02.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/get_current_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/get_current_address.c' -c -o objects/57425109602dc9647f4cb7cd44b302c1.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/get_current_offset.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/get_current_offset.c' -c -o objects/d873442c87c354d76412d0ce049942c4.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/get_end_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/get_end_address.c' -c -o objects/fc482ebc49bfe8a17848109056e7279e.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/get_start_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/get_start_address.c' -c -o objects/7a5d0f80e8d82880914da557613e134a.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/init.c' -c -o objects/95c7c4c5e6c1848006f2ada63a7bb564.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/move_current_offset_by_amount.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/move_current_offset_by_amount.c' -c -o objects/5a43af70606004c3a48771e6406dda97.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/reset_current_offset.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/reset_current_offset.c' -c -o objects/1dee7365b561d8deadeaf68db7b65f55.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/writeStringFormat.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/writeStringFormat.c' -c -o objects/844ca8afd9a3960017a244502735b8ee.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_char.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_char.c' -c -o objects/e8c2eb333a3952e6ca81e35abdad069c.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_string.c' -c -o objects/68b0e96014d6d561a9b1c65fa03d7341.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_u16be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_u16be.c' -c -o objects/a6347a91c60ddecc7e87306f5fa41a8f.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_u32be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_u32be.c' -c -o objects/6b1b0013d61af63733ea75c22e901055.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_u8.c' -c -o objects/98b108d516e71c18f307f919af164fa4.o
printf "ok\n"
printf "compiling 'build/module/nf-writer/public/write_u8_array.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/nf-writer/public/write_u8_array.c' -c -o objects/12047877b0f39e18dbcccce5fad96ed8.o
printf "ok\n"
printf "compiling 'build/module/os-timer/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/os-timer/public/create.c' -c -o objects/f02f86838fd3f383cec3abd88a93ae01.o
printf "ok\n"
printf "compiling 'build/module/os-timer/public/expired.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/os-timer/public/expired.c' -c -o objects/e9dd44500ecee35cb72f1977be215b14.o
printf "ok\n"
printf "compiling 'build/module/os-timer/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/os-timer/public/init.c' -c -o objects/64e2993403c013740106ed6ff079f4ce.o
printf "ok\n"
printf "compiling 'build/module/os-timer/public/restart.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/os-timer/public/restart.c' -c -o objects/dd49f0f3006208082a9b4c65b0685667.o
printf "ok\n"
printf "compiling 'build/module/os-timer/public/start.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/os-timer/public/start.c' -c -o objects/5373a9e3895327bf0b539073664ad616.o
printf "ok\n"
printf "compiling 'build/module/parser/_private/_count_occurrences.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/_private/_count_occurrences.c' -c -o objects/0c96a70532b38e01a2ecbf094ead2d09.o
printf "ok\n"
printf "compiling 'build/module/parser/_private/_parse_integer_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/_private/_parse_integer_string.c' -c -o objects/0ac9b3ae52115b65e2c09c827db466d4.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_boolean.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_boolean.c' -c -o objects/bb2e1fcf71f610ce158fcb97e092a5e0.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_decimal_number_u16.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_decimal_number_u16.c' -c -o objects/f16863f15feb99e9952691dae2854cb7.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_decimal_number_u32.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_decimal_number_u32.c' -c -o objects/5b554f7dacba0022470e2ff962377f2a.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_decimal_number_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_decimal_number_u8.c' -c -o objects/cdd912c847719df66e1ef06837b53522.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_hex_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_hex_string.c' -c -o objects/2bc2e86ade24cfbfa5889688716a13b4.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_hexadecimal_number_u16.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_hexadecimal_number_u16.c' -c -o objects/25d3462cbb726f2afb249cab42d0d2d7.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_hexadecimal_number_u32.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_hexadecimal_number_u32.c' -c -o objects/ce38cb2461876646acda4ff2d5197734.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_hexadecimal_number_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_hexadecimal_number_u8.c' -c -o objects/f473866d9491cfb69ba391e91bc182f5.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_ipv4_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_ipv4_address.c' -c -o objects/4ef3c604c5197bb164134cbf18072059.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_key_value.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_key_value.c' -c -o objects/ea28579e9435ddb3a098a206b80a1081.o
printf "ok\n"
printf "compiling 'build/module/parser/public/parse_mac_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/parser/public/parse_mac_address.c' -c -o objects/b48d328f6ba335d524920f6405d0cabb.o
printf "ok\n"
printf "compiling 'build/module/pool/public/allocate.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/allocate.c' -c -o objects/c1f335917d43a082ad39ca9693f9d6b4.o
printf "ok\n"
printf "compiling 'build/module/pool/public/claim_element.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/claim_element.c' -c -o objects/360b699430949183fb55071f56612d92.o
printf "ok\n"
printf "compiling 'build/module/pool/public/get_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/get_address.c' -c -o objects/e39de5b717cb1fa7f01ee4e24e137ae5.o
printf "ok\n"
printf "compiling 'build/module/pool/public/get_available.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/get_available.c' -c -o objects/97b61dd987dea6221c53c5eb27afcf6d.o
printf "ok\n"
printf "compiling 'build/module/pool/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/init.c' -c -o objects/406b190318ccf3e4a4c5655476bc3c33.o
printf "ok\n"
printf "compiling 'build/module/pool/public/is_allocated.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/is_allocated.c' -c -o objects/00b275c081a9ef2d573d9054ed76b508.o
printf "ok\n"
printf "compiling 'build/module/pool/public/is_claimed.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/is_claimed.c' -c -o objects/6dd0f5cd9ce65d2a278cabf6cd9efc8a.o
printf "ok\n"
printf "compiling 'build/module/pool/public/release.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/release.c' -c -o objects/9858cf3ab18e663689bbf45cce7cc645.o
printf "ok\n"
printf "compiling 'build/module/pool/public/release_element.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/pool/public/release_element.c' -c -o objects/b34c56e6f1adf5da35c3057f19578037.o
printf "ok\n"
printf "compiling 'build/module/random/_private/_consume_byte.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/_private/_consume_byte.c' -c -o objects/80e5ed72eb0563335ecc783eb6918f0a.o
printf "ok\n"
printf "compiling 'build/module/random/_private/_get_byte_used.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/_private/_get_byte_used.c' -c -o objects/d3cef8b28343056d877b0ed26167d594.o
printf "ok\n"
printf "compiling 'build/module/random/_private/_init_pool.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/_private/_init_pool.c' -c -o objects/35cad1f6174c15f9f9dbe1a24939ada6.o
printf "ok\n"
printf "compiling 'build/module/random/_private/_set_byte_used.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/_private/_set_byte_used.c' -c -o objects/0c4ca2a2b075e3159b810838feb65498.o
printf "ok\n"
printf "compiling 'build/module/random/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/_private/_vars.c' -c -o objects/2899f81335fa09795a0b90e9f9ca2125.o
printf "ok\n"
printf "compiling 'build/module/random/public/collect_bytes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/public/collect_bytes.c' -c -o objects/7c17cd3077ffa23ec42b56beae619997.o
printf "ok\n"
printf "compiling 'build/module/random/public/get_available_bytes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/public/get_available_bytes.c' -c -o objects/d87f681f3fe7fe7c880240deb4847477.o
printf "ok\n"
printf "compiling 'build/module/random/public/get_random_bytes.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/public/get_random_bytes.c' -c -o objects/f8470e5aa96373e96d2604a3cece3fcf.o
printf "ok\n"
printf "compiling 'build/module/random/public/get_random_bytes_sync.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/random/public/get_random_bytes_sync.c' -c -o objects/cc9909237e10fa9ea496d460656ffe45.o
printf "ok\n"
printf "compiling 'build/module/reader/_private/_check_access.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/_private/_check_access.c' -c -o objects/96d5599742d0a2648e6bbb116a1da919.o
printf "ok\n"
printf "compiling 'build/module/reader/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/create.c' -c -o objects/9dc478ddb6788c14810200bf6bf121f5.o
printf "ok\n"
printf "compiling 'build/module/reader/public/get_current_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/get_current_address.c' -c -o objects/6073936694931e3d19875c9f4781a6f0.o
printf "ok\n"
printf "compiling 'build/module/reader/public/get_current_offset.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/get_current_offset.c' -c -o objects/b76179f0e835e55d1f559d1fec3490db.o
printf "ok\n"
printf "compiling 'build/module/reader/public/get_end_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/get_end_address.c' -c -o objects/11e6b72da0f75845785fcd55b2f46188.o
printf "ok\n"
printf "compiling 'build/module/reader/public/get_start_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/get_start_address.c' -c -o objects/6e32110ac3d61493ddc8eccf1791b6d4.o
printf "ok\n"
printf "compiling 'build/module/reader/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/init.c' -c -o objects/9d38289840dfbfaa5ccf4cc70a496233.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_char.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_char.c' -c -o objects/b9742d3ea17af3b27307a4d28042f79b.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_line.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_line.c' -c -o objects/ffd2e347afe2e6227266e9b40e591d2a.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_string.c' -c -o objects/c5344bfbc0e7c676fdc6812a69f541dc.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_u16be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_u16be.c' -c -o objects/a5ea7fe6dd9a4830adced7d34cb43cb2.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_u32be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_u32be.c' -c -o objects/63af312bcfdae4ea1bebb723278b3c7c.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_u8.c' -c -o objects/6c91e17b7e4dfac4676968649cffe9f4.o
printf "ok\n"
printf "compiling 'build/module/reader/public/read_u8_array.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/reader/public/read_u8_array.c' -c -o objects/0e36261e7505343e2f57f1db7cbcbc7a.o
printf "ok\n"
printf "compiling 'build/module/sha/public/calculate.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/sha/public/calculate.c' -c -o objects/7dce90dab113edc9b8b5f750e26050a5.o
printf "ok\n"
printf "compiling 'build/module/timer/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/timer/public/create.c' -c -o objects/c392d2b0083138bdfd3f5c3c586e2f73.o
printf "ok\n"
printf "compiling 'build/module/timer/public/expired.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/timer/public/expired.c' -c -o objects/12b39d22c95d82f9ae2fc72d3361f1ae.o
printf "ok\n"
printf "compiling 'build/module/timer/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/timer/public/init.c' -c -o objects/83fee0e1d0a5457ab6cd87e8cc957392.o
printf "ok\n"
printf "compiling 'build/module/timer/public/restart.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/timer/public/restart.c' -c -o objects/155033d712154996b3e2fb6a2a47c999.o
printf "ok\n"
printf "compiling 'build/module/timer/public/start.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/timer/public/start.c' -c -o objects/20ac7dc63d2327a7184ace08502b66b9.o
printf "ok\n"
printf "compiling 'build/module/writer/_private/_check_access.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/_private/_check_access.c' -c -o objects/1901d02e314600877143f93f1a630c03.o
printf "ok\n"
printf "compiling 'build/module/writer/public/create.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/create.c' -c -o objects/149d02c4443095e57730a20f37cf0d83.o
printf "ok\n"
printf "compiling 'build/module/writer/public/get_current_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/get_current_address.c' -c -o objects/805f95d18018d0a0ce649d7ed7440d65.o
printf "ok\n"
printf "compiling 'build/module/writer/public/get_current_offset.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/get_current_offset.c' -c -o objects/7e2b1cd9e694a0fcbf56661226613e26.o
printf "ok\n"
printf "compiling 'build/module/writer/public/get_end_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/get_end_address.c' -c -o objects/90beb2607dc86bad560614daf4f3d657.o
printf "ok\n"
printf "compiling 'build/module/writer/public/get_start_address.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/get_start_address.c' -c -o objects/5d0fdda540ee800e8814f4c507498022.o
printf "ok\n"
printf "compiling 'build/module/writer/public/init.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/init.c' -c -o objects/0cc8f090b2525ec201d20bd574a06d32.o
printf "ok\n"
printf "compiling 'build/module/writer/public/move_current_offset_by_amount.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/move_current_offset_by_amount.c' -c -o objects/1eb51055ae396831abb9574dc23c22cf.o
printf "ok\n"
printf "compiling 'build/module/writer/public/reset_current_offset.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/reset_current_offset.c' -c -o objects/d44a8c7966a6327c362accc0c3038e5c.o
printf "ok\n"
printf "compiling 'build/module/writer/public/set_no_fail_mode.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/set_no_fail_mode.c' -c -o objects/5e1cdd58e60af70be626819a05c0f8f9.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_char.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_char.c' -c -o objects/2d9c2e211b2894cbd48df3bb1508928b.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_string.c' -c -o objects/0c96cb19c0277fa26aef126f43239c7e.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_string_format.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_string_format.c' -c -o objects/b750e2ab07fb0f701c1da4964b94ca62.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_u16be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_u16be.c' -c -o objects/94b6542a26c55dbd49e3d8fd8e12cb5c.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_u32be.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_u32be.c' -c -o objects/f9e19ded473f33fd13ba2ddf53c1d4d8.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_u8.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_u8.c' -c -o objects/043db642fc7552c8a54b331d7ae9e697.o
printf "ok\n"
printf "compiling 'build/module/writer/public/write_u8_array.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/module/writer/public/write_u8_array.c' -c -o objects/c25c4344e13d9315640645c358cd0534.o
printf "ok\n"
printf "compiling 'build/napc-core/HAL/linux/HAL_napc_getFreeMemory.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-core/HAL/linux/HAL_napc_getFreeMemory.c' -c -o objects/35bbb5c09fec687e122a369f625ab30f.o
printf "ok\n"
printf "compiling 'build/napc-core/public/get_free_memory.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-core/public/get_free_memory.c' -c -o objects/a591589c19f8f1f6bf7356a7dbf7ca52.o
printf "ok\n"
printf "compiling 'build/napc-core/public/get_uptime.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-core/public/get_uptime.c' -c -o objects/7c8261f5f08bced91597e97408929110.o
printf "ok\n"
printf "compiling 'build/napc-core/public/main.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-core/public/main.c' -c -o objects/2e34adcdd63c9498fc7d8e75df51fa50.o
printf "ok\n"
printf "compiling 'build/napc-delay/HAL/linux/HAL_napc_delay.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-delay/HAL/linux/HAL_napc_delay.c' -c -o objects/596f846ad1586d67c392fff868235cb7.o
printf "ok\n"
printf "compiling 'build/napc-delay/HAL/linux/HAL_napc_delayUs.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-delay/HAL/linux/HAL_napc_delayUs.c' -c -o objects/b926cbd8837fc4bd5f7b76e1b13af238.o
printf "ok\n"
printf "compiling 'build/napc-delay/public/delay.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-delay/public/delay.c' -c -o objects/bc34b13ca9818c01f0feb8ad4f03b923.o
printf "ok\n"
printf "compiling 'build/napc-delay/public/delay_us.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-delay/public/delay_us.c' -c -o objects/192d386054029afbeedd8f869cc9e3a8.o
printf "ok\n"
printf "compiling 'build/napc-log/_private/_init_log_handler.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/_private/_init_log_handler.c' -c -o objects/e16980cef4b20b3454452fabf7afccf2.o
printf "ok\n"
printf "compiling 'build/napc-log/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/_private/_vars.c' -c -o objects/38f641925dd32af1e889c6f2bbea1b19.o
printf "ok\n"
printf "compiling 'build/napc-log/public/add_log_handler_function.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/public/add_log_handler_function.c' -c -o objects/ec0fed317d6529b92f01c4f4ee77c3ea.o
printf "ok\n"
printf "compiling 'build/napc-log/public/log_level_to_string.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/public/log_level_to_string.c' -c -o objects/add413dd7563fb3360917c73b4e90625.o
printf "ok\n"
printf "compiling 'build/napc-log/public/log_message.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/public/log_message.c' -c -o objects/48619ef7926bfafce3272b96715c4fff.o
printf "ok\n"
printf "compiling 'build/napc-log/public/remove_log_handler_function.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-log/public/remove_log_handler_function.c' -c -o objects/3a59a35cf4cfea18cff3fa8472de321c.o
printf "ok\n"
printf "compiling 'build/napc-panic/HAL/linux/HAL_napc_abort.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-panic/HAL/linux/HAL_napc_abort.c' -c -o objects/59d83c8059334c17d58f584b677d8377.o
printf "ok\n"
printf "compiling 'build/napc-panic/public/halt.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-panic/public/halt.c' -c -o objects/39f84a03e31ad1b449501088d051d2ed.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/HAL/linux/HAL_napc_getRandomBit.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/HAL/linux/HAL_napc_getRandomBit.c' -c -o objects/11b8642c3499a3502d3cb479f23f6fdf.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/HAL/linux/HAL_napc_getRandomBitSources.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/HAL/linux/HAL_napc_getRandomBitSources.c' -c -o objects/51304a3f83b786355b30d810e1274b72.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/HAL/linux/HAL_napc_initRandomBitSources.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/HAL/linux/HAL_napc_initRandomBitSources.c' -c -o objects/6527c8d6384657488429b0514cbf839f.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/public/get_random_bit.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/public/get_random_bit.c' -c -o objects/efc5d65258b43d9705faea2464dd2de8.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/public/get_random_bit_sources.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/public/get_random_bit_sources.c' -c -o objects/cd73622effe94f5849ebd4699a3a7d5a.o
printf "ok\n"
printf "compiling 'build/napc-rand-source/public/get_random_byte.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-rand-source/public/get_random_byte.c' -c -o objects/becf6d6f6261ba8f6acc84aaaffe4120.o
printf "ok\n"
printf "compiling 'build/napc-serial/HAL/linux/HAL_napc_initSerial.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/HAL/linux/HAL_napc_initSerial.c' -c -o objects/524e033e26d23a0b7a62e8d7e2e215f2.o
printf "ok\n"
printf "compiling 'build/napc-serial/HAL/linux/HAL_napc_putc.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/HAL/linux/HAL_napc_putc.c' -c -o objects/ddb17be54aa09682717a9ac6ab7e6aed.o
printf "ok\n"
printf "compiling 'build/napc-serial/HAL/linux/HAL_napc_puts.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/HAL/linux/HAL_napc_puts.c' -c -o objects/85f3c8c5184c7ba3721fcff648947ccc.o
printf "ok\n"
printf "compiling 'build/napc-serial/_private/_vars.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/_private/_vars.c' -c -o objects/7998beb58bcfe08075b514adc45825c1.o
printf "ok\n"
printf "compiling 'build/napc-serial/public/mute.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/public/mute.c' -c -o objects/41c2048af4f68b5e527d62bab26db645.o
printf "ok\n"
printf "compiling 'build/napc-serial/public/printf.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/public/printf.c' -c -o objects/71b1d337cab5d320e72aa25265d6d835.o
printf "ok\n"
printf "compiling 'build/napc-serial/public/putc.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/public/putc.c' -c -o objects/78ca107d956ad42fff7f2be1eb3a3990.o
printf "ok\n"
printf "compiling 'build/napc-serial/public/puts.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/public/puts.c' -c -o objects/07fab5744c54e7bdaa93ab1deece7209.o
printf "ok\n"
printf "compiling 'build/napc-serial/public/unmute.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-serial/public/unmute.c' -c -o objects/8790fc8817f7b71e0589b697e0d0fe3d.o
printf "ok\n"
printf "compiling 'build/napc-time/HAL/linux/HAL_napc_getTimeSinceBoot.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-time/HAL/linux/HAL_napc_getTimeSinceBoot.c' -c -o objects/50094421169ca625cead796b13d2055d.o
printf "ok\n"
printf "compiling 'build/napc-time/HAL/linux/HAL_napc_initTime.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-time/HAL/linux/HAL_napc_initTime.c' -c -o objects/98a038c3b1913d7647679ba124d11b44.o
printf "ok\n"
printf "compiling 'build/napc-time/public/get_time_since_boot.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-time/public/get_time_since_boot.c' -c -o objects/5abdea935cd67a5e6e44d8cc98f16873.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/memeql.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/memeql.c' -c -o objects/5e5bc87d5ee9926854761ac7ea1efc0e.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/mzero.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/mzero.c' -c -o objects/356e8d5cfe3ddf3bd56f22b7721581f5.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/snprintf.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/snprintf.c' -c -o objects/d1bf5c4f535d8fce2547210774f7f91a.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/streql.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/streql.c' -c -o objects/6211eb459dfed9179485b3be5845f3ce.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/streqli.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/streqli.c' -c -o objects/2ef43151ad52b395fd05f4a03d6df04b.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/strlen.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/strlen.c' -c -o objects/ab3e45f8c854451c584227fe1668e866.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/strncpy.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/strncpy.c' -c -o objects/8426fa628cf3e785ad4183eb9bc9e9b4.o
printf "ok\n"
printf "compiling 'build/napc-utils/public/vsnprintf.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/napc-utils/public/vsnprintf.c' -c -o objects/6a1c2282b2e190c0e759adfc83757046.o
printf "ok\n"
printf "compiling 'build/testing.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/testing.c' -c -o objects/d41b8e0e8f797f6c431872a66178df37.o
printf "ok\n"
printf "compiling 'build/version.c' ... "
gcc -Wall -Wextra -Wpedantic -Wno-gnu-zero-variadic-macro-arguments -Werror -I./build 'build/version.c' -c -o objects/a6b54802a6d97be48f89d799988a67c4.o
printf "ok\n"
ar rcs libnapc.a 'objects/2442eccd1145d677675793958d27da2b.o'
ar rcs libnapc.a 'objects/e752f083b11788676c545db7caa46ac6.o'
ar rcs libnapc.a 'objects/0326ddded5f8968abe2215a1cc6d2770.o'
ar rcs libnapc.a 'objects/8a3b5fef4fc4433289147d70bb786867.o'
ar rcs libnapc.a 'objects/daca8835d8ecf252c085c29738546c14.o'
ar rcs libnapc.a 'objects/c865ec75c45026b8fecb03e2c9e3d141.o'
ar rcs libnapc.a 'objects/afc216680732e22ee1112cfd7e8cbd85.o'
ar rcs libnapc.a 'objects/f7faaad1b9c69c0c2be741e73915b718.o'
ar rcs libnapc.a 'objects/f5c602f40dbbf3af68c1f8206ffefc34.o'
ar rcs libnapc.a 'objects/45b889966d1ff63dfe3d74cf8c5fa542.o'
ar rcs libnapc.a 'objects/a429de2814ac72e94c5f9ffc64115e7c.o'
ar rcs libnapc.a 'objects/bffee34a94bff1cba15594a9decfa8d3.o'
ar rcs libnapc.a 'objects/55060ab01491d73cdc9f88f1e95472ae.o'
ar rcs libnapc.a 'objects/d09c9556aaa1c1ba713e1fe06d592f69.o'
ar rcs libnapc.a 'objects/d24855ccd2165c775d617dd93d0d6a57.o'
ar rcs libnapc.a 'objects/4492044b4870c5bab7984dd6b7f79460.o'
ar rcs libnapc.a 'objects/9b89903e92d9eef7db1c0329e5c81d27.o'
ar rcs libnapc.a 'objects/ff566ede9a71782a284604f5e8116195.o'
ar rcs libnapc.a 'objects/5bb42028c586a7691ea1ea65c95f56d0.o'
ar rcs libnapc.a 'objects/3d4c049afe34f0c6b15e13ccd82feccf.o'
ar rcs libnapc.a 'objects/2e64a743fb6ec0111cc0329f4f23416a.o'
ar rcs libnapc.a 'objects/41fc4731b4ab11b560f26c97e1c89720.o'
ar rcs libnapc.a 'objects/b0da0b82792bf36e10002fbaa38f319f.o'
ar rcs libnapc.a 'objects/fdc1252d15cbae154d3151efc10bd699.o'
ar rcs libnapc.a 'objects/eae15a7ee2eaf610a38d4a6775d5b726.o'
ar rcs libnapc.a 'objects/cd631b43ab1ab5c249c88216cbe3e3d3.o'
ar rcs libnapc.a 'objects/0a60852bef591b7c98cb01af062035a1.o'
ar rcs libnapc.a 'objects/4180a94a54b5632b6f08a021256c65c5.o'
ar rcs libnapc.a 'objects/ce7f8867b74fbc3e115d8a764ae562df.o'
ar rcs libnapc.a 'objects/a0813717abfb259bc27f69fd32927db1.o'
ar rcs libnapc.a 'objects/9d6ef5e72ed070ef55d71e6a7b687281.o'
ar rcs libnapc.a 'objects/ed407f34f600172b0ce13b8b662277e5.o'
ar rcs libnapc.a 'objects/683583f3e9049120a4ee8febcfc96888.o'
ar rcs libnapc.a 'objects/b67dd83bdb30d6ddad90f82c58a7c90d.o'
ar rcs libnapc.a 'objects/72cce4224962949c7d6e53e0120235a4.o'
ar rcs libnapc.a 'objects/1f23b5299c3d45148ffe3d66b9ff8d70.o'
ar rcs libnapc.a 'objects/b57a07d4de5342b3df5d09459fbe773a.o'
ar rcs libnapc.a 'objects/ba89435d1592a2aff798092f278d1d6f.o'
ar rcs libnapc.a 'objects/b03aaefb885f964fa5924a931b099b2f.o'
ar rcs libnapc.a 'objects/6217e167dc5a37273bbd9527143ac791.o'
ar rcs libnapc.a 'objects/e579f4e920631ea336f88b50a9b4ab1d.o'
ar rcs libnapc.a 'objects/6469d6a9fd506beb2cadec9cd3cc9797.o'
ar rcs libnapc.a 'objects/d07892d76548c6d681a40cee3fe22670.o'
ar rcs libnapc.a 'objects/9055ec7237e079ddd790594966788daa.o'
ar rcs libnapc.a 'objects/1aab434292b5ad1be0ba2b16d8db2243.o'
ar rcs libnapc.a 'objects/53936bc1778d21ecafe729c5fcb0ed8d.o'
ar rcs libnapc.a 'objects/f8c3acd65336d3ddce727054d47b60db.o'
ar rcs libnapc.a 'objects/d0370ed22fb4fd89a14904d581e31bbc.o'
ar rcs libnapc.a 'objects/fea6bb9a8f4d147da34c7ec5e067e86a.o'
ar rcs libnapc.a 'objects/87004529a13ea86ea6852eaf1b74f0b4.o'
ar rcs libnapc.a 'objects/63d13efb9d6b48051b4df9123b134c9d.o'
ar rcs libnapc.a 'objects/8b89df4f76e26639a50cfc874ac01bfe.o'
ar rcs libnapc.a 'objects/6a9faa9495ab9813bbd7375f4e1e3f9b.o'
ar rcs libnapc.a 'objects/23faba048e211e96cd74e3e2ffc8cc0e.o'
ar rcs libnapc.a 'objects/6d6d6d1e6208670ec4bff1bb83263b1f.o'
ar rcs libnapc.a 'objects/56d3758c3eb4cafc0ad16c689a593bea.o'
ar rcs libnapc.a 'objects/a386e4116521362a9bd7874d366061a5.o'
ar rcs libnapc.a 'objects/13050139e00b931aff45cbea19336cce.o'
ar rcs libnapc.a 'objects/1c6b438775c3fe319d616cf946af2e5d.o'
ar rcs libnapc.a 'objects/3d73b4c42932403efb71cc97d85b71b4.o'
ar rcs libnapc.a 'objects/dd9d6e2d97724882e7ffd4450f1ecf4d.o'
ar rcs libnapc.a 'objects/106739e0fe708e7aa2bc5bf8df43491b.o'
ar rcs libnapc.a 'objects/52058a804744f49e06b954d230641986.o'
ar rcs libnapc.a 'objects/ac719711a7298b36afcd58a4141e37c3.o'
ar rcs libnapc.a 'objects/f2209c36a39f6af6109ae59c0ff87cb7.o'
ar rcs libnapc.a 'objects/dd9b1c434cc1e804774aefd61ffd5109.o'
ar rcs libnapc.a 'objects/b42c3990389f1af72ceaef5a74db5833.o'
ar rcs libnapc.a 'objects/1c4e7b3a1a1b31cb2831f65fec430ec0.o'
ar rcs libnapc.a 'objects/8d9df0e1e6e6b0f4ae1c0cccd29a604b.o'
ar rcs libnapc.a 'objects/73432abbd59f730bbd50594ac83c6100.o'
ar rcs libnapc.a 'objects/1ddf90221f2f954620811da65dfe477d.o'
ar rcs libnapc.a 'objects/b72d3240003d4feb9cda89b81afa0fb0.o'
ar rcs libnapc.a 'objects/9972aa83789ab778992d3a0a33acd06c.o'
ar rcs libnapc.a 'objects/828cd3e7ab4e1425daf7c4bb03d79008.o'
ar rcs libnapc.a 'objects/6175a14739dbe0c140f667cd2667a5af.o'
ar rcs libnapc.a 'objects/0824d408fb7bb8da3543c4465c859320.o'
ar rcs libnapc.a 'objects/aba538fddcfc56b3a01cb1c5a0d20af7.o'
ar rcs libnapc.a 'objects/d754ea6e5b2bc8fb52013d0829345597.o'
ar rcs libnapc.a 'objects/becb442a366cb2e34a8e305d79e0ea4a.o'
ar rcs libnapc.a 'objects/3e669a18d377968ffd144ca4b438483b.o'
ar rcs libnapc.a 'objects/f29937a7e454de91fa1ed6dc7911f198.o'
ar rcs libnapc.a 'objects/fbd6478c0a016d326a7cf102f39f32e1.o'
ar rcs libnapc.a 'objects/34f38fe4b23911dfa222b5ed0ebfc05e.o'
ar rcs libnapc.a 'objects/d69bacc17ec109a10e7255484e4a1c68.o'
ar rcs libnapc.a 'objects/227d83453fd8c4182f424549c44a662e.o'
ar rcs libnapc.a 'objects/079998410e9228f4bb4253f30f47b5f4.o'
ar rcs libnapc.a 'objects/b3c484fa445a00dd7537afe644224ee5.o'
ar rcs libnapc.a 'objects/e77aaf3b61cb8f9aea68b079440af456.o'
ar rcs libnapc.a 'objects/dfeeadc59f316d1313341c8de3d58960.o'
ar rcs libnapc.a 'objects/71039262cff6d07e542f195b15d29463.o'
ar rcs libnapc.a 'objects/a8a8131445565ea163c1286b6446b389.o'
ar rcs libnapc.a 'objects/bbf550bec24d12e7500fc227ad8f6783.o'
ar rcs libnapc.a 'objects/5e1aa042c42336aeeff4cca5ace09b4c.o'
ar rcs libnapc.a 'objects/18c1a3b8bc6d1c1d813a3d4b21de5c7f.o'
ar rcs libnapc.a 'objects/00ad3f6a7308064cc17fffd92796db38.o'
ar rcs libnapc.a 'objects/62b7257abf982e1eb1d0dab862ee473e.o'
ar rcs libnapc.a 'objects/4a96d6d77ebb28f07551d102d6e8e54d.o'
ar rcs libnapc.a 'objects/9774d0cff7bf375d44ca812968b90667.o'
ar rcs libnapc.a 'objects/5fff8b5c2f0186ed4694f014e26e9946.o'
ar rcs libnapc.a 'objects/6f6c51151fc6b1f1395aed2160014606.o'
ar rcs libnapc.a 'objects/d349c4d3763ac6cba7f15a559dd0fe81.o'
ar rcs libnapc.a 'objects/9ffed193b3cac07cfc382d15e7dc2317.o'
ar rcs libnapc.a 'objects/73fc0c161a246e6b633ce2d1e02f64e0.o'
ar rcs libnapc.a 'objects/fcef3902df2e66dc5d7fa2b06058d09d.o'
ar rcs libnapc.a 'objects/1273795adf70565b19c50b24fd60420a.o'
ar rcs libnapc.a 'objects/671db48d9703cb8dfa445d98718af770.o'
ar rcs libnapc.a 'objects/b8a9c94730bd50436dc83dc9084aa186.o'
ar rcs libnapc.a 'objects/6b08075011d299f37c876805c1087d2c.o'
ar rcs libnapc.a 'objects/a6e83c8bb96dc8b2081d308bc44bcac8.o'
ar rcs libnapc.a 'objects/6263c76d0f1ec1f48add149854c2f38c.o'
ar rcs libnapc.a 'objects/4d1ae1e153a98f5ec269435532325874.o'
ar rcs libnapc.a 'objects/d1c2692e4af84cb115d4dea9c76c3206.o'
ar rcs libnapc.a 'objects/5830e0989122c8a1c2c18fb7f79e8eae.o'
ar rcs libnapc.a 'objects/49d9298df5bc7bcab848d5b8ea04fec2.o'
ar rcs libnapc.a 'objects/839c59de9d073f3dbe5391c3a21f6a24.o'
ar rcs libnapc.a 'objects/dabf2e62e281fc65db5f698682456694.o'
ar rcs libnapc.a 'objects/4d382bd04f921c21578e0b7603086fb3.o'
ar rcs libnapc.a 'objects/c4e645a8c5ac9569ad77cb5f6ee7f106.o'
ar rcs libnapc.a 'objects/7f2402bec86966006b3fda66047bd3af.o'
ar rcs libnapc.a 'objects/9d1df0ffa3fd537491afe94ce007478e.o'
ar rcs libnapc.a 'objects/0b7e6535feab2fd6c7d57012e571aee7.o'
ar rcs libnapc.a 'objects/381f0b7f858a86226f2ef87e23db39d2.o'
ar rcs libnapc.a 'objects/d0fd1f12e03b36eec1e025d82f6c8b6c.o'
ar rcs libnapc.a 'objects/a83a679a0448a10971bebc5265099c96.o'
ar rcs libnapc.a 'objects/215853900eab938cfe036a27b484ebf3.o'
ar rcs libnapc.a 'objects/32adacb67dd4e3c7a339d131a379c12f.o'
ar rcs libnapc.a 'objects/3b520a398fadd33d3376a8b83e395b6c.o'
ar rcs libnapc.a 'objects/7f28d30e8a31784801fdd7622b250b02.o'
ar rcs libnapc.a 'objects/57425109602dc9647f4cb7cd44b302c1.o'
ar rcs libnapc.a 'objects/d873442c87c354d76412d0ce049942c4.o'
ar rcs libnapc.a 'objects/fc482ebc49bfe8a17848109056e7279e.o'
ar rcs libnapc.a 'objects/7a5d0f80e8d82880914da557613e134a.o'
ar rcs libnapc.a 'objects/95c7c4c5e6c1848006f2ada63a7bb564.o'
ar rcs libnapc.a 'objects/5a43af70606004c3a48771e6406dda97.o'
ar rcs libnapc.a 'objects/1dee7365b561d8deadeaf68db7b65f55.o'
ar rcs libnapc.a 'objects/844ca8afd9a3960017a244502735b8ee.o'
ar rcs libnapc.a 'objects/e8c2eb333a3952e6ca81e35abdad069c.o'
ar rcs libnapc.a 'objects/68b0e96014d6d561a9b1c65fa03d7341.o'
ar rcs libnapc.a 'objects/a6347a91c60ddecc7e87306f5fa41a8f.o'
ar rcs libnapc.a 'objects/6b1b0013d61af63733ea75c22e901055.o'
ar rcs libnapc.a 'objects/98b108d516e71c18f307f919af164fa4.o'
ar rcs libnapc.a 'objects/12047877b0f39e18dbcccce5fad96ed8.o'
ar rcs libnapc.a 'objects/f02f86838fd3f383cec3abd88a93ae01.o'
ar rcs libnapc.a 'objects/e9dd44500ecee35cb72f1977be215b14.o'
ar rcs libnapc.a 'objects/64e2993403c013740106ed6ff079f4ce.o'
ar rcs libnapc.a 'objects/dd49f0f3006208082a9b4c65b0685667.o'
ar rcs libnapc.a 'objects/5373a9e3895327bf0b539073664ad616.o'
ar rcs libnapc.a 'objects/0c96a70532b38e01a2ecbf094ead2d09.o'
ar rcs libnapc.a 'objects/0ac9b3ae52115b65e2c09c827db466d4.o'
ar rcs libnapc.a 'objects/bb2e1fcf71f610ce158fcb97e092a5e0.o'
ar rcs libnapc.a 'objects/f16863f15feb99e9952691dae2854cb7.o'
ar rcs libnapc.a 'objects/5b554f7dacba0022470e2ff962377f2a.o'
ar rcs libnapc.a 'objects/cdd912c847719df66e1ef06837b53522.o'
ar rcs libnapc.a 'objects/2bc2e86ade24cfbfa5889688716a13b4.o'
ar rcs libnapc.a 'objects/25d3462cbb726f2afb249cab42d0d2d7.o'
ar rcs libnapc.a 'objects/ce38cb2461876646acda4ff2d5197734.o'
ar rcs libnapc.a 'objects/f473866d9491cfb69ba391e91bc182f5.o'
ar rcs libnapc.a 'objects/4ef3c604c5197bb164134cbf18072059.o'
ar rcs libnapc.a 'objects/ea28579e9435ddb3a098a206b80a1081.o'
ar rcs libnapc.a 'objects/b48d328f6ba335d524920f6405d0cabb.o'
ar rcs libnapc.a 'objects/c1f335917d43a082ad39ca9693f9d6b4.o'
ar rcs libnapc.a 'objects/360b699430949183fb55071f56612d92.o'
ar rcs libnapc.a 'objects/e39de5b717cb1fa7f01ee4e24e137ae5.o'
ar rcs libnapc.a 'objects/97b61dd987dea6221c53c5eb27afcf6d.o'
ar rcs libnapc.a 'objects/406b190318ccf3e4a4c5655476bc3c33.o'
ar rcs libnapc.a 'objects/00b275c081a9ef2d573d9054ed76b508.o'
ar rcs libnapc.a 'objects/6dd0f5cd9ce65d2a278cabf6cd9efc8a.o'
ar rcs libnapc.a 'objects/9858cf3ab18e663689bbf45cce7cc645.o'
ar rcs libnapc.a 'objects/b34c56e6f1adf5da35c3057f19578037.o'
ar rcs libnapc.a 'objects/80e5ed72eb0563335ecc783eb6918f0a.o'
ar rcs libnapc.a 'objects/d3cef8b28343056d877b0ed26167d594.o'
ar rcs libnapc.a 'objects/35cad1f6174c15f9f9dbe1a24939ada6.o'
ar rcs libnapc.a 'objects/0c4ca2a2b075e3159b810838feb65498.o'
ar rcs libnapc.a 'objects/2899f81335fa09795a0b90e9f9ca2125.o'
ar rcs libnapc.a 'objects/7c17cd3077ffa23ec42b56beae619997.o'
ar rcs libnapc.a 'objects/d87f681f3fe7fe7c880240deb4847477.o'
ar rcs libnapc.a 'objects/f8470e5aa96373e96d2604a3cece3fcf.o'
ar rcs libnapc.a 'objects/cc9909237e10fa9ea496d460656ffe45.o'
ar rcs libnapc.a 'objects/96d5599742d0a2648e6bbb116a1da919.o'
ar rcs libnapc.a 'objects/9dc478ddb6788c14810200bf6bf121f5.o'
ar rcs libnapc.a 'objects/6073936694931e3d19875c9f4781a6f0.o'
ar rcs libnapc.a 'objects/b76179f0e835e55d1f559d1fec3490db.o'
ar rcs libnapc.a 'objects/11e6b72da0f75845785fcd55b2f46188.o'
ar rcs libnapc.a 'objects/6e32110ac3d61493ddc8eccf1791b6d4.o'
ar rcs libnapc.a 'objects/9d38289840dfbfaa5ccf4cc70a496233.o'
ar rcs libnapc.a 'objects/b9742d3ea17af3b27307a4d28042f79b.o'
ar rcs libnapc.a 'objects/ffd2e347afe2e6227266e9b40e591d2a.o'
ar rcs libnapc.a 'objects/c5344bfbc0e7c676fdc6812a69f541dc.o'
ar rcs libnapc.a 'objects/a5ea7fe6dd9a4830adced7d34cb43cb2.o'
ar rcs libnapc.a 'objects/63af312bcfdae4ea1bebb723278b3c7c.o'
ar rcs libnapc.a 'objects/6c91e17b7e4dfac4676968649cffe9f4.o'
ar rcs libnapc.a 'objects/0e36261e7505343e2f57f1db7cbcbc7a.o'
ar rcs libnapc.a 'objects/7dce90dab113edc9b8b5f750e26050a5.o'
ar rcs libnapc.a 'objects/c392d2b0083138bdfd3f5c3c586e2f73.o'
ar rcs libnapc.a 'objects/12b39d22c95d82f9ae2fc72d3361f1ae.o'
ar rcs libnapc.a 'objects/83fee0e1d0a5457ab6cd87e8cc957392.o'
ar rcs libnapc.a 'objects/155033d712154996b3e2fb6a2a47c999.o'
ar rcs libnapc.a 'objects/20ac7dc63d2327a7184ace08502b66b9.o'
ar rcs libnapc.a 'objects/1901d02e314600877143f93f1a630c03.o'
ar rcs libnapc.a 'objects/149d02c4443095e57730a20f37cf0d83.o'
ar rcs libnapc.a 'objects/805f95d18018d0a0ce649d7ed7440d65.o'
ar rcs libnapc.a 'objects/7e2b1cd9e694a0fcbf56661226613e26.o'
ar rcs libnapc.a 'objects/90beb2607dc86bad560614daf4f3d657.o'
ar rcs libnapc.a 'objects/5d0fdda540ee800e8814f4c507498022.o'
ar rcs libnapc.a 'objects/0cc8f090b2525ec201d20bd574a06d32.o'
ar rcs libnapc.a 'objects/1eb51055ae396831abb9574dc23c22cf.o'
ar rcs libnapc.a 'objects/d44a8c7966a6327c362accc0c3038e5c.o'
ar rcs libnapc.a 'objects/5e1cdd58e60af70be626819a05c0f8f9.o'
ar rcs libnapc.a 'objects/2d9c2e211b2894cbd48df3bb1508928b.o'
ar rcs libnapc.a 'objects/0c96cb19c0277fa26aef126f43239c7e.o'
ar rcs libnapc.a 'objects/b750e2ab07fb0f701c1da4964b94ca62.o'
ar rcs libnapc.a 'objects/94b6542a26c55dbd49e3d8fd8e12cb5c.o'
ar rcs libnapc.a 'objects/f9e19ded473f33fd13ba2ddf53c1d4d8.o'
ar rcs libnapc.a 'objects/043db642fc7552c8a54b331d7ae9e697.o'
ar rcs libnapc.a 'objects/c25c4344e13d9315640645c358cd0534.o'
ar rcs libnapc.a 'objects/35bbb5c09fec687e122a369f625ab30f.o'
ar rcs libnapc.a 'objects/a591589c19f8f1f6bf7356a7dbf7ca52.o'
ar rcs libnapc.a 'objects/7c8261f5f08bced91597e97408929110.o'
ar rcs libnapc.a 'objects/2e34adcdd63c9498fc7d8e75df51fa50.o'
ar rcs libnapc.a 'objects/596f846ad1586d67c392fff868235cb7.o'
ar rcs libnapc.a 'objects/b926cbd8837fc4bd5f7b76e1b13af238.o'
ar rcs libnapc.a 'objects/bc34b13ca9818c01f0feb8ad4f03b923.o'
ar rcs libnapc.a 'objects/192d386054029afbeedd8f869cc9e3a8.o'
ar rcs libnapc.a 'objects/e16980cef4b20b3454452fabf7afccf2.o'
ar rcs libnapc.a 'objects/38f641925dd32af1e889c6f2bbea1b19.o'
ar rcs libnapc.a 'objects/ec0fed317d6529b92f01c4f4ee77c3ea.o'
ar rcs libnapc.a 'objects/add413dd7563fb3360917c73b4e90625.o'
ar rcs libnapc.a 'objects/48619ef7926bfafce3272b96715c4fff.o'
ar rcs libnapc.a 'objects/3a59a35cf4cfea18cff3fa8472de321c.o'
ar rcs libnapc.a 'objects/59d83c8059334c17d58f584b677d8377.o'
ar rcs libnapc.a 'objects/39f84a03e31ad1b449501088d051d2ed.o'
ar rcs libnapc.a 'objects/11b8642c3499a3502d3cb479f23f6fdf.o'
ar rcs libnapc.a 'objects/51304a3f83b786355b30d810e1274b72.o'
ar rcs libnapc.a 'objects/6527c8d6384657488429b0514cbf839f.o'
ar rcs libnapc.a 'objects/efc5d65258b43d9705faea2464dd2de8.o'
ar rcs libnapc.a 'objects/cd73622effe94f5849ebd4699a3a7d5a.o'
ar rcs libnapc.a 'objects/becf6d6f6261ba8f6acc84aaaffe4120.o'
ar rcs libnapc.a 'objects/524e033e26d23a0b7a62e8d7e2e215f2.o'
ar rcs libnapc.a 'objects/ddb17be54aa09682717a9ac6ab7e6aed.o'
ar rcs libnapc.a 'objects/85f3c8c5184c7ba3721fcff648947ccc.o'
ar rcs libnapc.a 'objects/7998beb58bcfe08075b514adc45825c1.o'
ar rcs libnapc.a 'objects/41c2048af4f68b5e527d62bab26db645.o'
ar rcs libnapc.a 'objects/71b1d337cab5d320e72aa25265d6d835.o'
ar rcs libnapc.a 'objects/78ca107d956ad42fff7f2be1eb3a3990.o'
ar rcs libnapc.a 'objects/07fab5744c54e7bdaa93ab1deece7209.o'
ar rcs libnapc.a 'objects/8790fc8817f7b71e0589b697e0d0fe3d.o'
ar rcs libnapc.a 'objects/50094421169ca625cead796b13d2055d.o'
ar rcs libnapc.a 'objects/98a038c3b1913d7647679ba124d11b44.o'
ar rcs libnapc.a 'objects/5abdea935cd67a5e6e44d8cc98f16873.o'
ar rcs libnapc.a 'objects/5e5bc87d5ee9926854761ac7ea1efc0e.o'
ar rcs libnapc.a 'objects/356e8d5cfe3ddf3bd56f22b7721581f5.o'
ar rcs libnapc.a 'objects/d1bf5c4f535d8fce2547210774f7f91a.o'
ar rcs libnapc.a 'objects/6211eb459dfed9179485b3be5845f3ce.o'
ar rcs libnapc.a 'objects/2ef43151ad52b395fd05f4a03d6df04b.o'
ar rcs libnapc.a 'objects/ab3e45f8c854451c584227fe1668e866.o'
ar rcs libnapc.a 'objects/8426fa628cf3e785ad4183eb9bc9e9b4.o'
ar rcs libnapc.a 'objects/6a1c2282b2e190c0e759adfc83757046.o'
ar rcs libnapc.a 'objects/d41b8e0e8f797f6c431872a66178df37.o'
ar rcs libnapc.a 'objects/a6b54802a6d97be48f89d799988a67c4.o'
