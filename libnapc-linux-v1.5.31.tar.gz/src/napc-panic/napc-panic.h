/*
* MIT License
* 
* Copyright (c) 2022 nap.software
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/
#if !defined(NAPC_PANIC_h)
	#define NAPC_PANIC_h

	#include <libnapc.h>

	void napc_halt(
		const char *file,
		int file_line,
		const char *fn,
		const char *fmt,
		...
	) NAPC_FN_PRINTFLIKE(4, 5);

	/*!
	 * @name NAPC_PANIC
	 * @module Core
	 * @brief Abort program execution.
	 * @version 1.0.0
	 * @description
	 * Abort program execution and print a message.
	 * @param _cstring_ fmt printf()-like format string.
	 * @param n/a ... Values to incorporate into string.
	 * @changelog 1.0.0 17.02.2022 initial version
	 * @example
	 * NAPC_PANIC("Some error occurred: %s", "Could not open file");
	 */
	#define NAPC_PANIC(fmt, ...) \
		napc_halt(__FILE__, __LINE__, __func__, fmt, ## __VA_ARGS__)
#endif
