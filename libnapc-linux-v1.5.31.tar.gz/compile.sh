#!/bin/bash -euf
printf "Compiling 'src/__tests__/__tests__.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/__tests__.c' -c -o 'objects/f0c1e9478fd1b501c0ff9088e74e06e3.o'
printf "Compiling 'src/__tests__/aes/aes_basic.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/aes/aes_basic.c' -c -o 'objects/0dea1f58855f47f87c3d7be241fe732c.o'
printf "Compiling 'src/__tests__/dns/dns_parse_header.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/dns/dns_parse_header.c' -c -o 'objects/cc7fc6d681341db592b4f8b8bef35974.o'
printf "Compiling 'src/__tests__/dns/dns_parse_request_A.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/dns/dns_parse_request_A.c' -c -o 'objects/8c362cdf6ec5d10138a300568358d553.o'
printf "Compiling 'src/__tests__/dns/dns_parse_request_AAAA.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/dns/dns_parse_request_AAAA.c' -c -o 'objects/801f8d70eec28113674ac2e003640cc6.o'
printf "Compiling 'src/__tests__/dns/dns_parse_response_A.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/dns/dns_parse_response_A.c' -c -o 'objects/e2176f7324d65ba2f9d645eebd049f8c.o'
printf "Compiling 'src/__tests__/dns/dns_parse_response_AAAA.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/dns/dns_parse_response_AAAA.c' -c -o 'objects/9d4dbcabf309466bcf3f52f549789af5.o'
printf "Compiling 'src/__tests__/eth/eth_broadcast_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/eth/eth_broadcast_address.c' -c -o 'objects/1dd0d4e445b5a339a7f14d7fa1c75c0d.o'
printf "Compiling 'src/__tests__/hmac/hmac_calculate.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/hmac/hmac_calculate.c' -c -o 'objects/d3408824f4818b132ad940cab6bb9f2c.o'
printf "Compiling 'src/__tests__/hmac/hmac_verify.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/hmac/hmac_verify.c' -c -o 'objects/0b93c770ecf98e6500c7d0f58a42a643.o'
printf "Compiling 'src/__tests__/misc/misc_chunks_impartial.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/misc/misc_chunks_impartial.c' -c -o 'objects/7b238616039459e347afc2260d6f5514.o'
printf "Compiling 'src/__tests__/misc/misc_memory_fence.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/misc/misc_memory_fence.c' -c -o 'objects/7755b6a970d034f95dc03b49fe7b9ca3.o'
printf "Compiling 'src/__tests__/misc/misc_shift_array_right.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/misc/misc_shift_array_right.c' -c -o 'objects/5ebd9a9971f00260cc19b74345cce40f.o'
printf "Compiling 'src/__tests__/parser/parser_parse_boolean.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_boolean.c' -c -o 'objects/fb94bf24f38b1724df83219d15181090.o'
printf "Compiling 'src/__tests__/parser/parser_parse_decimal_number_u16.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_decimal_number_u16.c' -c -o 'objects/0c3ff27b39e9e91af119ddf19a4651a5.o'
printf "Compiling 'src/__tests__/parser/parser_parse_decimal_number_u32.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_decimal_number_u32.c' -c -o 'objects/992fb6a72a2244267970ed92bbbe9010.o'
printf "Compiling 'src/__tests__/parser/parser_parse_decimal_number_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_decimal_number_u8.c' -c -o 'objects/e4836d19ff94dbae597a0daf8f475352.o'
printf "Compiling 'src/__tests__/parser/parser_parse_hex_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_hex_string.c' -c -o 'objects/173f9c58af9ba3f56caa123cb1a547dd.o'
printf "Compiling 'src/__tests__/parser/parser_parse_hexadecimal_number_u16.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_hexadecimal_number_u16.c' -c -o 'objects/0c34cf8909bfea60a0c497dea7faeef0.o'
printf "Compiling 'src/__tests__/parser/parser_parse_hexadecimal_number_u32.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_hexadecimal_number_u32.c' -c -o 'objects/c064fe1619a521af4b8ca04d40d2b07d.o'
printf "Compiling 'src/__tests__/parser/parser_parse_hexadecimal_number_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_hexadecimal_number_u8.c' -c -o 'objects/fa4c895ecb1ce776981065260ca6b9a1.o'
printf "Compiling 'src/__tests__/parser/parser_parse_ipv4_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_ipv4_address.c' -c -o 'objects/06978da0239ef0d1a2c0e9f27947d45f.o'
printf "Compiling 'src/__tests__/parser/parser_parse_key_value.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_key_value.c' -c -o 'objects/3d07209759b511a6e9f38a602a455c21.o'
printf "Compiling 'src/__tests__/parser/parser_parse_mac_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/parser/parser_parse_mac_address.c' -c -o 'objects/65e8872a34b860a617ee11045844bf87.o'
printf "Compiling 'src/__tests__/pool/pool_basic.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/pool/pool_basic.c' -c -o 'objects/f35c51b7b83ca91a4cc5b752c1e8162b.o'
printf "Compiling 'src/__tests__/reader/reader_char.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_char.c' -c -o 'objects/58f3aa24e0ae90ddbd6f09306601057d.o'
printf "Compiling 'src/__tests__/reader/reader_get_current_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_get_current_address.c' -c -o 'objects/5e479ce09e5fed21c489237b6637d8d9.o'
printf "Compiling 'src/__tests__/reader/reader_get_end_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_get_end_address.c' -c -o 'objects/b4dd9abb0c051cb171587a596b102aff.o'
printf "Compiling 'src/__tests__/reader/reader_get_start_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_get_start_address.c' -c -o 'objects/7988957087dec554f6ab05a70a995d1a.o'
printf "Compiling 'src/__tests__/reader/reader_line.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_line.c' -c -o 'objects/eb2026e9dca03d5b5638b529944a76af.o'
printf "Compiling 'src/__tests__/reader/reader_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_string.c' -c -o 'objects/49fc0a00e7c6ee41c57fcd6766dcd479.o'
printf "Compiling 'src/__tests__/reader/reader_u16be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_u16be.c' -c -o 'objects/0dce8841c063dc950882e531a5a4022d.o'
printf "Compiling 'src/__tests__/reader/reader_u32be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_u32be.c' -c -o 'objects/1d7d84a9894049aff5e65e22d254dbc1.o'
printf "Compiling 'src/__tests__/reader/reader_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_u8.c' -c -o 'objects/bdb22ea809d4db3e72647650314443e4.o'
printf "Compiling 'src/__tests__/reader/reader_u8_array.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/reader/reader_u8_array.c' -c -o 'objects/9553bb4290c4cb909a9e9436f22f5510.o'
printf "Compiling 'src/__tests__/sha/sha_basic.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/sha/sha_basic.c' -c -o 'objects/23e173b33e7b162724631e5208bd7ab0.o'
printf "Compiling 'src/__tests__/writer/writer_char.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_char.c' -c -o 'objects/97401f6515f6f943e74df7b7e7ae199a.o'
printf "Compiling 'src/__tests__/writer/writer_get_current_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_get_current_address.c' -c -o 'objects/c3629a5bc1d5c4bb7b32a5533e5bb4e5.o'
printf "Compiling 'src/__tests__/writer/writer_get_end_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_get_end_address.c' -c -o 'objects/56bbf920e74443ddba5bb05587f6f279.o'
printf "Compiling 'src/__tests__/writer/writer_get_start_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_get_start_address.c' -c -o 'objects/5b8c0e82eb21337e5b5338bcd8f41849.o'
printf "Compiling 'src/__tests__/writer/writer_move_current_offset_by_amount.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_move_current_offset_by_amount.c' -c -o 'objects/968e6a6a99d47943d958fbd4dce9688f.o'
printf "Compiling 'src/__tests__/writer/writer_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_string.c' -c -o 'objects/31fefa2beace6f67f2d8cfb7cee32c91.o'
printf "Compiling 'src/__tests__/writer/writer_string_format.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_string_format.c' -c -o 'objects/a995c48c8a26a898ba3915e90d5e2564.o'
printf "Compiling 'src/__tests__/writer/writer_u16be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_u16be.c' -c -o 'objects/20a54bbbe7eea39924c632e05fcea0f6.o'
printf "Compiling 'src/__tests__/writer/writer_u32be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_u32be.c' -c -o 'objects/678ce28d56d83305810cceaccd0f0047.o'
printf "Compiling 'src/__tests__/writer/writer_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/__tests__/writer/writer_u8.c' -c -o 'objects/34867fad559a631092bcf236a5fd2f83.o'
printf "Compiling 'src/boot/linux.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/boot/linux.c' -c -o 'objects/0ef1e95523c2faa156ea3b53aad7d141.o'
printf "Compiling 'src/boot_functions.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/boot_functions.c' -c -o 'objects/387791dec2f998db7353761cfb77e6a2.o'
printf "Compiling 'src/hw.module/env/public/is_ethernet_available.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/env/public/is_ethernet_available.c' -c -o 'objects/19a2e7c7116d036716a22b2e56fe755a.o'
printf "Compiling 'src/hw.module/env/public/is_file_system_available.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/env/public/is_file_system_available.c' -c -o 'objects/1fa60672170db08f61d436af24b0f460.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_eth_getLinkStatus.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_eth_getLinkStatus.c' -c -o 'objects/24b0829608aba80882101defec9e49e3.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setGatewayAddress.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setGatewayAddress.c' -c -o 'objects/e568fa11961b4942b1e7b55bb76d38f9.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setIPAddress.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setIPAddress.c' -c -o 'objects/72cfdf4e2383395259996777b7405b92.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setMACAddress.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setMACAddress.c' -c -o 'objects/a7fa54bbfd454c26202763b328f8d98f.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setSubnetMask.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_eth_setSubnetMask.c' -c -o 'objects/613e2097b6a4748fadfe466552e59d86.o'
printf "Compiling 'src/hw.module/eth/HAL/linux/HAL_napc_initEthernet.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/HAL/linux/HAL_napc_initEthernet.c' -c -o 'objects/f137822f60da332541efba34ec6363ac.o'
printf "Compiling 'src/hw.module/eth/_private/_assert_initialized.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/_private/_assert_initialized.c' -c -o 'objects/4b5cdc6dcd239ff3f9d0753d410df9e6.o'
printf "Compiling 'src/hw.module/eth/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/_private/_vars.c' -c -o 'objects/9e0bcfa6bd04893c785600a642d41a88.o'
printf "Compiling 'src/hw.module/eth/public/calculate_broadcast_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/calculate_broadcast_address.c' -c -o 'objects/4a53d9e1e21b899a255881a73768ffaa.o'
printf "Compiling 'src/hw.module/eth/public/get_link_status.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/get_link_status.c' -c -o 'objects/5a86829ed07f0edd56be93bafc9cb19b.o'
printf "Compiling 'src/hw.module/eth/public/set_gateway_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/set_gateway_address.c' -c -o 'objects/55b651dce79b96548df33274a61362e2.o'
printf "Compiling 'src/hw.module/eth/public/set_ip_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/set_ip_address.c' -c -o 'objects/26286fde75f9f3bebea349fccaf9a146.o'
printf "Compiling 'src/hw.module/eth/public/set_mac_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/set_mac_address.c' -c -o 'objects/3781012fd43ef4a817c8e18917e6b1fb.o'
printf "Compiling 'src/hw.module/eth/public/set_subnet_mask.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/eth/public/set_subnet_mask.c' -c -o 'objects/d07519d265b02e16d4548e35a58f733a.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_File_close.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_File_close.c' -c -o 'objects/eaeffe76b197154cf60a6ac1de10da6e.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_File_getSize.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_File_getSize.c' -c -o 'objects/e6903ab89dbd5cc18b03804ef996c12b.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_File_open.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_File_open.c' -c -o 'objects/dba50f1c21fa233b6412d954b7f934a0.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_File_read.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_File_read.c' -c -o 'objects/495d341d5e1c54121af132612b0d5b9b.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_File_write.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_File_write.c' -c -o 'objects/f9025d4b3d0bbcdef6f74831ca588bf6.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_initFileSystem.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_initFileSystem.c' -c -o 'objects/3950844ff4662d44168e6c14fefde64c.o'
printf "Compiling 'src/hw.module/file/HAL/linux/HAL_napc_initFileSystemHandlesPool.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/HAL/linux/HAL_napc_initFileSystemHandlesPool.c' -c -o 'objects/d95a6cf2473af4c3ddc55e8baa261adf.o'
printf "Compiling 'src/hw.module/file/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/_private/_vars.c' -c -o 'objects/fcc94430e1ab4ace1ce3ad0875615afb.o'
printf "Compiling 'src/hw.module/file/public/close.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/public/close.c' -c -o 'objects/969f6ab7fdb8b3f3c5d41e35e48e45fb.o'
printf "Compiling 'src/hw.module/file/public/get_size.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/public/get_size.c' -c -o 'objects/8a9543a41aa9d5a1284355dc9d63a414.o'
printf "Compiling 'src/hw.module/file/public/open.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/public/open.c' -c -o 'objects/3ea5ee4276d929230519b9536c316776.o'
printf "Compiling 'src/hw.module/file/public/read.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/public/read.c' -c -o 'objects/c70392bf8845344ba6a2cd81d6b079d7.o'
printf "Compiling 'src/hw.module/file/public/write.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/file/public/write.c' -c -o 'objects/a67b7919fcaab21f3c74090b9a3a3212.o'
printf "Compiling 'src/hw.module/fs/_private/_read_file_chunk.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/_private/_read_file_chunk.c' -c -o 'objects/c6e7b47cb21d48aa15be786355628122.o'
printf "Compiling 'src/hw.module/fs/_private/_write_file_chunk.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/_private/_write_file_chunk.c' -c -o 'objects/e739e7e3f5cb7759fd35608d649de312.o'
printf "Compiling 'src/hw.module/fs/public/read_file.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/public/read_file.c' -c -o 'objects/ac9be2c44b2c14b9153f63237e19464a.o'
printf "Compiling 'src/hw.module/fs/public/read_file_c_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/public/read_file_c_string.c' -c -o 'objects/0858c9d1a17009b0f876f475280b4ed9.o'
printf "Compiling 'src/hw.module/fs/public/write_file.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/public/write_file.c' -c -o 'objects/2647aea7a09dac4139b1dd87572ff76f.o'
printf "Compiling 'src/hw.module/fs/public/write_file_c_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/fs/public/write_file_c_string.c' -c -o 'objects/d599b6c1c80be9ff74bdd55a5d43d9cc.o'
printf "Compiling 'src/hw.module/platform/linux/napc_linux__bindSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/platform/linux/napc_linux__bindSocket.c' -c -o 'objects/af9e404d0e398f45c14553e8313048df.o'
printf "Compiling 'src/hw.module/platform/linux/napc_linux__createAddressStruct.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/platform/linux/napc_linux__createAddressStruct.c' -c -o 'objects/0284afd5e58238c74ac45e666af32f26.o'
printf "Compiling 'src/hw.module/platform/linux/napc_linux__createUDPSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/platform/linux/napc_linux__createUDPSocket.c' -c -o 'objects/b5257114f3daa14a41f447ebcd33fc47.o'
printf "Compiling 'src/hw.module/platform/linux/napc_linux__readFromUDPSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/platform/linux/napc_linux__readFromUDPSocket.c' -c -o 'objects/7e57453291094f8d9cfac254c92be0ad.o'
printf "Compiling 'src/hw.module/platform/linux/napc_linux__writeToUDPSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/platform/linux/napc_linux__writeToUDPSocket.c' -c -o 'objects/6c32cd6a967751449ca1fb3a7c8d93b3.o'
printf "Compiling 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_closeSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_closeSocket.c' -c -o 'objects/c3a1dcf5c0ead6208bfd9dc9569d01a9.o'
printf "Compiling 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_createSocket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_createSocket.c' -c -o 'objects/5a467e95aa379170e578ba15af03f914.o'
printf "Compiling 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_initSocketPool.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_initSocketPool.c' -c -o 'objects/c2330b50cdb3470408631b68899552f3.o'
printf "Compiling 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_receive.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_receive.c' -c -o 'objects/688782fb3aaa836d97dce5347334e5cd.o'
printf "Compiling 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_send.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/HAL/linux/HAL_napc_UDP_send.c' -c -o 'objects/d16d519b30a9a99e2580850eba8dc9df.o'
printf "Compiling 'src/hw.module/udp/_private/_log_message.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/_private/_log_message.c' -c -o 'objects/2921edcda390fa435733bf607b8a5921.o'
printf "Compiling 'src/hw.module/udp/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/_private/_vars.c' -c -o 'objects/a22022a6f39e1ad493481c092fe6ab47.o'
printf "Compiling 'src/hw.module/udp/public/close_socket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/close_socket.c' -c -o 'objects/dadc73df3bde9b4d726ad953afec4744.o'
printf "Compiling 'src/hw.module/udp/public/create_socket.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/create_socket.c' -c -o 'objects/13cb2b8ed70187216872fb8c7b26d838.o'
printf "Compiling 'src/hw.module/udp/public/get_num_open_sockets.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/get_num_open_sockets.c' -c -o 'objects/7ce426e8a1031ce5c06c7447fc459ec7.o'
printf "Compiling 'src/hw.module/udp/public/receive.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/receive.c' -c -o 'objects/f63a51d257ebc3e78c008d2e95a321d8.o'
printf "Compiling 'src/hw.module/udp/public/send.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/send.c' -c -o 'objects/34b17a04dd45d54cb8c3916f4fe0e641.o'
printf "Compiling 'src/hw.module/udp/public/send_silent.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/hw.module/udp/public/send_silent.c' -c -o 'objects/4f5a3623f526af1a4988837c376a272d.o'
printf "Compiling 'src/module/aes/_private/_tinyaes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/aes/_private/_tinyaes.c' -c -o 'objects/307de34d781c47607327d68ea91c8be8.o'
printf "Compiling 'src/module/aes/public/decrypt.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/aes/public/decrypt.c' -c -o 'objects/36a3c9a7ccbb671510945c76cd5208d2.o'
printf "Compiling 'src/module/aes/public/encrypt.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/aes/public/encrypt.c' -c -o 'objects/b16614409970bd0e512f160271dddda9.o'
printf "Compiling 'src/module/app/public/loop.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/app/public/loop.c' -c -o 'objects/b9cb209ba2bf8531d3245d31fbdde61d.o'
printf "Compiling 'src/module/app/public/setup.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/app/public/setup.c' -c -o 'objects/08d05258ebc9028b1c6c53d3b8363579.o'
printf "Compiling 'src/module/buffer/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/buffer/public/create.c' -c -o 'objects/c533140b78bc82d9c0e349dc802e5fd5.o'
printf "Compiling 'src/module/buffer/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/buffer/public/init.c' -c -o 'objects/38dfafe1edb7d74d619d441578561125.o'
printf "Compiling 'src/module/dns/_private/_dn_expand.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/_private/_dn_expand.c' -c -o 'objects/a7d68cd3f0d8083d3c56685429455636.o'
printf "Compiling 'src/module/dns/_private/_parse_answer_section.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/_private/_parse_answer_section.c' -c -o 'objects/02f89ea095d5eb104b97a3be56f0a987.o'
printf "Compiling 'src/module/dns/_private/_parse_query_section.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/_private/_parse_query_section.c' -c -o 'objects/e8169df9bc2b1aefa5895f4853c3eaea.o'
printf "Compiling 'src/module/dns/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/_private/_vars.c' -c -o 'objects/cf1e83a5e23e26ff5ac1c935d7df461f.o'
printf "Compiling 'src/module/dns/public/parse_header.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/public/parse_header.c' -c -o 'objects/049d0eb5f82278f62ddbcf9b40628f6e.o'
printf "Compiling 'src/module/dns/public/parse_request.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/public/parse_request.c' -c -o 'objects/7337d2635388018a0b44c3370c968ec6.o'
printf "Compiling 'src/module/dns/public/parse_response.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/dns/public/parse_response.c' -c -o 'objects/a002bc8afebd1d99dfde28ab082aabe3.o'
printf "Compiling 'src/module/hmac/_private/h5p9sl/_hmac-sha256.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hmac/_private/h5p9sl/_hmac-sha256.c' -c -o 'objects/30a9de55714df5086fca2ccd0efb98a6.o'
printf "Compiling 'src/module/hmac/_private/h5p9sl/_sha256.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hmac/_private/h5p9sl/_sha256.c' -c -o 'objects/42132ad0b9493b24f406df7e83c714f6.o'
printf "Compiling 'src/module/hmac/public/calculate.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hmac/public/calculate.c' -c -o 'objects/a5aa41106e965ad1247cd89e1280754f.o'
printf "Compiling 'src/module/hmac/public/verify.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hmac/public/verify.c' -c -o 'objects/5ecce97de42eec974d8480e4bec57ecf.o'
printf "Compiling 'src/module/hr-timer/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/create.c' -c -o 'objects/765db23901898439cc92f529ed5f1dee.o'
printf "Compiling 'src/module/hr-timer/public/expired.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/expired.c' -c -o 'objects/5b7e9d1b896972dd8213ec515dc977cf.o'
printf "Compiling 'src/module/hr-timer/public/getMode.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/getMode.c' -c -o 'objects/951a071ee3f889c78c0d473acab5c936.o'
printf "Compiling 'src/module/hr-timer/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/init.c' -c -o 'objects/0285f884ff0847e252eb20040ce98bd4.o'
printf "Compiling 'src/module/hr-timer/public/restart.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/restart.c' -c -o 'objects/3f2e26bd50bf05e7322ca12817f0861f.o'
printf "Compiling 'src/module/hr-timer/public/start.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/hr-timer/public/start.c' -c -o 'objects/81d7bcfc3b5c9d08abbb19dab64387ac.o'
printf "Compiling 'src/module/ipv4participant/public/copy.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/ipv4participant/public/copy.c' -c -o 'objects/f3d5d733e3f2c1449c1b72d39784c860.o'
printf "Compiling 'src/module/ipv4participant/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/ipv4participant/public/create.c' -c -o 'objects/73d90425a3e329480f061f44f1f795c2.o'
printf "Compiling 'src/module/ipv4participant/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/ipv4participant/public/init.c' -c -o 'objects/1d51b0269d61faccf302336cd23608b8.o'
printf "Compiling 'src/module/misc/public/chunked_operation.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/misc/public/chunked_operation.c' -c -o 'objects/ed96683d2cea2271587e5aeace96a141.o'
printf "Compiling 'src/module/misc/public/print_hex_array.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/misc/public/print_hex_array.c' -c -o 'objects/9e4488dbd5c96fbb22449c4a625a52a6.o'
printf "Compiling 'src/module/misc/public/set_memory_fence_bytes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/misc/public/set_memory_fence_bytes.c' -c -o 'objects/ec0c254f6dea7a9ade2ebe5310f0e657.o'
printf "Compiling 'src/module/misc/public/shift_array_right.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/misc/public/shift_array_right.c' -c -o 'objects/5dc2d835d1fed28972e99133cc98d0f4.o'
printf "Compiling 'src/module/misc/public/verify_memory_fence_bytes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/misc/public/verify_memory_fence_bytes.c' -c -o 'objects/58c2877115226644de88342bb40ab54c.o'
printf "Compiling 'src/module/nf-writer/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/create.c' -c -o 'objects/4b7bde1f7e1720e3598576c16190ebae.o'
printf "Compiling 'src/module/nf-writer/public/get_current_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/get_current_address.c' -c -o 'objects/5ca47c5219740c0018b74fa19edd9c60.o'
printf "Compiling 'src/module/nf-writer/public/get_current_offset.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/get_current_offset.c' -c -o 'objects/d037b4438e99aae313f2a634afc70dc8.o'
printf "Compiling 'src/module/nf-writer/public/get_end_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/get_end_address.c' -c -o 'objects/b3d1ea787b134c1f369c935f368a326e.o'
printf "Compiling 'src/module/nf-writer/public/get_start_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/get_start_address.c' -c -o 'objects/783b6da28ff7642520f7a00e936a1a8b.o'
printf "Compiling 'src/module/nf-writer/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/init.c' -c -o 'objects/c47bc777f8729e32af68b6160a77e7ac.o'
printf "Compiling 'src/module/nf-writer/public/move_current_offset_by_amount.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/move_current_offset_by_amount.c' -c -o 'objects/29b6f29917747c47e65885e35373f6b8.o'
printf "Compiling 'src/module/nf-writer/public/reset_current_offset.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/reset_current_offset.c' -c -o 'objects/7ff281c7ac52ae8843e5fbbb0ada4118.o'
printf "Compiling 'src/module/nf-writer/public/writeStringFormat.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/writeStringFormat.c' -c -o 'objects/950b0e63c253533dfaecf94db12262f9.o'
printf "Compiling 'src/module/nf-writer/public/write_char.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_char.c' -c -o 'objects/0455fc0bff05757be88cacb776b495b6.o'
printf "Compiling 'src/module/nf-writer/public/write_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_string.c' -c -o 'objects/5d8d34d3af4dbbd5fa2e96d608bd9420.o'
printf "Compiling 'src/module/nf-writer/public/write_u16be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_u16be.c' -c -o 'objects/3e296f966f2a87dd46c8450fb3cf2a63.o'
printf "Compiling 'src/module/nf-writer/public/write_u32be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_u32be.c' -c -o 'objects/617768696466e9a69455fdcc598ab2a2.o'
printf "Compiling 'src/module/nf-writer/public/write_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_u8.c' -c -o 'objects/c0b84f4e2af8417ba9577b86b0754dec.o'
printf "Compiling 'src/module/nf-writer/public/write_u8_array.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/nf-writer/public/write_u8_array.c' -c -o 'objects/cf8e244eb47140dff9501d9aca91c43c.o'
printf "Compiling 'src/module/parser/_private/_count_occurrences.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/_private/_count_occurrences.c' -c -o 'objects/37d1d345e72ed4a042cce3a234554332.o'
printf "Compiling 'src/module/parser/_private/_parse_integer_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/_private/_parse_integer_string.c' -c -o 'objects/288430c4785aede8488cc248fc6ca431.o'
printf "Compiling 'src/module/parser/public/parse_boolean.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_boolean.c' -c -o 'objects/c9f250069c71198216cd3f48ee9d1a5e.o'
printf "Compiling 'src/module/parser/public/parse_decimal_number_u16.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_decimal_number_u16.c' -c -o 'objects/8d6b818437d2771662246ca64e357ac5.o'
printf "Compiling 'src/module/parser/public/parse_decimal_number_u32.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_decimal_number_u32.c' -c -o 'objects/c570e238969bf7336acfbf258ff851f0.o'
printf "Compiling 'src/module/parser/public/parse_decimal_number_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_decimal_number_u8.c' -c -o 'objects/7ab2543b860572e95f578bc1d918856e.o'
printf "Compiling 'src/module/parser/public/parse_hex_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_hex_string.c' -c -o 'objects/75706a72931858748f485c90ce3c211e.o'
printf "Compiling 'src/module/parser/public/parse_hexadecimal_number_u16.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_hexadecimal_number_u16.c' -c -o 'objects/44aad1e40bdb89bc995a037259f233fe.o'
printf "Compiling 'src/module/parser/public/parse_hexadecimal_number_u32.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_hexadecimal_number_u32.c' -c -o 'objects/3c857d82684a786d92fc4b11abebae41.o'
printf "Compiling 'src/module/parser/public/parse_hexadecimal_number_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_hexadecimal_number_u8.c' -c -o 'objects/21207a2bcc0aa597b5ea484262b4c7bb.o'
printf "Compiling 'src/module/parser/public/parse_ipv4_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_ipv4_address.c' -c -o 'objects/8f7c384531570e47fc368313f8c338a2.o'
printf "Compiling 'src/module/parser/public/parse_key_value.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_key_value.c' -c -o 'objects/50066eba7b20fd73db5c0640800536a9.o'
printf "Compiling 'src/module/parser/public/parse_mac_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/parser/public/parse_mac_address.c' -c -o 'objects/937ba56a810a474acac7b7f0b9ebea56.o'
printf "Compiling 'src/module/pool/public/allocate.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/allocate.c' -c -o 'objects/39a6f21e4f28e8e8b86494d97225e6e9.o'
printf "Compiling 'src/module/pool/public/claim_element.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/claim_element.c' -c -o 'objects/6a352a73a928d9498fe2d90fb59d87c9.o'
printf "Compiling 'src/module/pool/public/get_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/get_address.c' -c -o 'objects/0c6e60a278bcff080af3f5c842cdb1ca.o'
printf "Compiling 'src/module/pool/public/get_available.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/get_available.c' -c -o 'objects/4d58fabe889609034688622ac9c2e962.o'
printf "Compiling 'src/module/pool/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/init.c' -c -o 'objects/51360b5823f70cc050f1ce4024b4e2a4.o'
printf "Compiling 'src/module/pool/public/is_allocated.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/is_allocated.c' -c -o 'objects/4905aa472b4a8853f7d93ca6ed2abda6.o'
printf "Compiling 'src/module/pool/public/is_claimed.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/is_claimed.c' -c -o 'objects/29a14ffc459486750797cb6f510d2516.o'
printf "Compiling 'src/module/pool/public/release.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/release.c' -c -o 'objects/3050ff50b8f4011af702b1c4dcd498bb.o'
printf "Compiling 'src/module/pool/public/release_element.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/pool/public/release_element.c' -c -o 'objects/29d5b96968ec4b151714f11a271be1d7.o'
printf "Compiling 'src/module/random/_private/_consume_byte.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/_private/_consume_byte.c' -c -o 'objects/d49055044a13bf9553bb5aed5e5471f4.o'
printf "Compiling 'src/module/random/_private/_get_byte_used.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/_private/_get_byte_used.c' -c -o 'objects/7c048f796fc2dacbad806b6a71c7b7ec.o'
printf "Compiling 'src/module/random/_private/_init_pool.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/_private/_init_pool.c' -c -o 'objects/a5d985d22b9fdb164ebd365528fc9634.o'
printf "Compiling 'src/module/random/_private/_set_byte_used.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/_private/_set_byte_used.c' -c -o 'objects/761fc0085f14fc48ace696d1b37cefb1.o'
printf "Compiling 'src/module/random/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/_private/_vars.c' -c -o 'objects/a336efe424733c20cbdaafb19aaf6f4c.o'
printf "Compiling 'src/module/random/public/collect_bytes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/public/collect_bytes.c' -c -o 'objects/5e14d455007f1c33cde181826ed5fcdb.o'
printf "Compiling 'src/module/random/public/get_available_bytes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/public/get_available_bytes.c' -c -o 'objects/cc377cdc895368b03cfaa9a142936f8e.o'
printf "Compiling 'src/module/random/public/get_random_bytes.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/public/get_random_bytes.c' -c -o 'objects/2a166317d50541b5c8ca8814c35ee474.o'
printf "Compiling 'src/module/random/public/get_random_bytes_sync.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/random/public/get_random_bytes_sync.c' -c -o 'objects/b617500837103a249cf5e452f526f239.o'
printf "Compiling 'src/module/reader/_private/_check_access.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/_private/_check_access.c' -c -o 'objects/6e3a9113ab04bfec83b53c0757befd27.o'
printf "Compiling 'src/module/reader/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/create.c' -c -o 'objects/d98e2c9ada9f8f819a87875105068f68.o'
printf "Compiling 'src/module/reader/public/get_current_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/get_current_address.c' -c -o 'objects/49f00ecc59e7c3b5ad34e079cf00386e.o'
printf "Compiling 'src/module/reader/public/get_current_offset.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/get_current_offset.c' -c -o 'objects/5af9a082306bdfc7261495e4a7e30838.o'
printf "Compiling 'src/module/reader/public/get_end_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/get_end_address.c' -c -o 'objects/dcae2f334ab418bb67497ab0e072c37e.o'
printf "Compiling 'src/module/reader/public/get_start_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/get_start_address.c' -c -o 'objects/28bd1a5ef42f2a05401a040a3f1b8338.o'
printf "Compiling 'src/module/reader/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/init.c' -c -o 'objects/a7b09421928f797c85a7d0597dfe7e6f.o'
printf "Compiling 'src/module/reader/public/read_char.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_char.c' -c -o 'objects/10583c55bc98550db8e2e7e16524104a.o'
printf "Compiling 'src/module/reader/public/read_line.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_line.c' -c -o 'objects/6c27fbf4b959a33995258804fe21e5ec.o'
printf "Compiling 'src/module/reader/public/read_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_string.c' -c -o 'objects/ddbd069e8259acc872e4c931c85476ba.o'
printf "Compiling 'src/module/reader/public/read_u16be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_u16be.c' -c -o 'objects/ab607130c890c513b8b417c654923c90.o'
printf "Compiling 'src/module/reader/public/read_u32be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_u32be.c' -c -o 'objects/0765e79eacbb196badab3c050abfa146.o'
printf "Compiling 'src/module/reader/public/read_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_u8.c' -c -o 'objects/8d8891418492bf66b95664d9d53a0cd3.o'
printf "Compiling 'src/module/reader/public/read_u8_array.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/reader/public/read_u8_array.c' -c -o 'objects/84963e34d968a404b89b9aa719087d92.o'
printf "Compiling 'src/module/sha/public/calculate.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/sha/public/calculate.c' -c -o 'objects/6c1a061c0c651c6cf7534f5923f29bd3.o'
printf "Compiling 'src/module/timer/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/create.c' -c -o 'objects/2760c2a9d32d21e825145333fa34e333.o'
printf "Compiling 'src/module/timer/public/expired.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/expired.c' -c -o 'objects/6b4e0003f596a8f78825123c2bf40a9f.o'
printf "Compiling 'src/module/timer/public/getMode.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/getMode.c' -c -o 'objects/104b3669bd9ed026fa704f7503ec31c9.o'
printf "Compiling 'src/module/timer/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/init.c' -c -o 'objects/a57b0446b322748bd157d4f013b38743.o'
printf "Compiling 'src/module/timer/public/restart.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/restart.c' -c -o 'objects/bf1d7337f360163cd29f4f183d146371.o'
printf "Compiling 'src/module/timer/public/start.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/timer/public/start.c' -c -o 'objects/3df9e0def99a65305b50862617081421.o'
printf "Compiling 'src/module/writer/_private/_check_access.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/_private/_check_access.c' -c -o 'objects/ad8581024808b8bb7ecdb8bfa191df60.o'
printf "Compiling 'src/module/writer/public/create.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/create.c' -c -o 'objects/7dd22eefbd3e5a60133ea97df87e7794.o'
printf "Compiling 'src/module/writer/public/get_current_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/get_current_address.c' -c -o 'objects/5e9db0e93dbf6cd649387d2af319fb7f.o'
printf "Compiling 'src/module/writer/public/get_current_offset.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/get_current_offset.c' -c -o 'objects/3fb91227118e7cd8e427f485edbcd5ef.o'
printf "Compiling 'src/module/writer/public/get_end_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/get_end_address.c' -c -o 'objects/a6c61ce893012e5e6c4ebb34ede9f65f.o'
printf "Compiling 'src/module/writer/public/get_start_address.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/get_start_address.c' -c -o 'objects/558bb61ebb90b74006e06b7b793e36a0.o'
printf "Compiling 'src/module/writer/public/init.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/init.c' -c -o 'objects/91980ce79a09dda7e3c7ee11b8f59bd9.o'
printf "Compiling 'src/module/writer/public/move_current_offset_by_amount.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/move_current_offset_by_amount.c' -c -o 'objects/ea9dac151b1a4b36b0cc3bb8373d6532.o'
printf "Compiling 'src/module/writer/public/reset_current_offset.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/reset_current_offset.c' -c -o 'objects/e47063747e00382865fb592adc7c1ad4.o'
printf "Compiling 'src/module/writer/public/set_no_fail_mode.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/set_no_fail_mode.c' -c -o 'objects/2fd3351dca0bfed86f7635fa7cf646a6.o'
printf "Compiling 'src/module/writer/public/write_char.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_char.c' -c -o 'objects/2b71db954c41818dc2602034e80c52dc.o'
printf "Compiling 'src/module/writer/public/write_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_string.c' -c -o 'objects/50cdd3a8e8c0a45659907f0615098b95.o'
printf "Compiling 'src/module/writer/public/write_string_format.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_string_format.c' -c -o 'objects/8f826128bd184361a0a94c6ed920bb3f.o'
printf "Compiling 'src/module/writer/public/write_u16be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_u16be.c' -c -o 'objects/d6a91a3583df08f13ba8ab9551323d68.o'
printf "Compiling 'src/module/writer/public/write_u32be.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_u32be.c' -c -o 'objects/6989c5a05bf02eed6e4b1bb76b318e3e.o'
printf "Compiling 'src/module/writer/public/write_u8.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_u8.c' -c -o 'objects/2a4801d156e1c7109a59e9036988d60b.o'
printf "Compiling 'src/module/writer/public/write_u8_array.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/module/writer/public/write_u8_array.c' -c -o 'objects/23a8d3dc9039ac290c4ba59073e6b944.o'
printf "Compiling 'src/napc-core/HAL/linux/HAL_napc_getFreeMemory.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-core/HAL/linux/HAL_napc_getFreeMemory.c' -c -o 'objects/7160fec9a58760aa3aeedcee9ddf6c4b.o'
printf "Compiling 'src/napc-core/HAL/linux/HAL_napc_loopYieldCPU.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-core/HAL/linux/HAL_napc_loopYieldCPU.c' -c -o 'objects/d1f0867e029e4aef3cc8d67f86cf0436.o'
printf "Compiling 'src/napc-core/public/get_free_memory.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-core/public/get_free_memory.c' -c -o 'objects/ff72cf3e2890ba6c3025c4d8a4cb75d6.o'
printf "Compiling 'src/napc-core/public/get_uptime.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-core/public/get_uptime.c' -c -o 'objects/3090a5584b6427e871d9ad30a6eed599.o'
printf "Compiling 'src/napc-core/public/main.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-core/public/main.c' -c -o 'objects/c5b57295a0954a15684b91de761d9686.o'
printf "Compiling 'src/napc-delay/HAL/linux/HAL_napc_delay.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-delay/HAL/linux/HAL_napc_delay.c' -c -o 'objects/da6d132fe39e83152d5eb260b0e51356.o'
printf "Compiling 'src/napc-delay/HAL/linux/HAL_napc_delayUs.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-delay/HAL/linux/HAL_napc_delayUs.c' -c -o 'objects/47d2eb4a647c0927f5e3691c745f75e6.o'
printf "Compiling 'src/napc-delay/public/delay.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-delay/public/delay.c' -c -o 'objects/de8e279fdb7720aeebfd274dba4cc78a.o'
printf "Compiling 'src/napc-delay/public/delay_us.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-delay/public/delay_us.c' -c -o 'objects/e8bd909e096f62dae991ab10873b5e9b.o'
printf "Compiling 'src/napc-log/_private/_init_log_handler.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/_private/_init_log_handler.c' -c -o 'objects/d0d3634f19fcf114efacdb7e90ca0169.o'
printf "Compiling 'src/napc-log/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/_private/_vars.c' -c -o 'objects/5ed4f82059c9f5d7a996342dec68b2a8.o'
printf "Compiling 'src/napc-log/public/add_log_handler_function.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/public/add_log_handler_function.c' -c -o 'objects/92cc07797bd645b1e8bb6e145a5871e0.o'
printf "Compiling 'src/napc-log/public/log_level_to_string.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/public/log_level_to_string.c' -c -o 'objects/41b78eccfac2b5a838f22926cc6872fd.o'
printf "Compiling 'src/napc-log/public/log_message.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/public/log_message.c' -c -o 'objects/146758d7ff009bdf759e0cfe3f76939c.o'
printf "Compiling 'src/napc-log/public/remove_log_handler_function.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-log/public/remove_log_handler_function.c' -c -o 'objects/81a3d74d1b15a1dd970ed24c355df596.o'
printf "Compiling 'src/napc-panic/HAL/linux/HAL_napc_abort.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-panic/HAL/linux/HAL_napc_abort.c' -c -o 'objects/35f5003726ddc1a56e270c318b1689d8.o'
printf "Compiling 'src/napc-panic/public/halt.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-panic/public/halt.c' -c -o 'objects/c65fc71b4f9862d0962bce30c854a9b1.o'
printf "Compiling 'src/napc-rand-source/HAL/linux/HAL_napc_getRandomBit.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/HAL/linux/HAL_napc_getRandomBit.c' -c -o 'objects/29a1b2c88561feef758cf87bac8ae849.o'
printf "Compiling 'src/napc-rand-source/HAL/linux/HAL_napc_getRandomBitSources.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/HAL/linux/HAL_napc_getRandomBitSources.c' -c -o 'objects/0d9351237a27a85c701c55fd291ff18e.o'
printf "Compiling 'src/napc-rand-source/HAL/linux/HAL_napc_initRandomBitSources.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/HAL/linux/HAL_napc_initRandomBitSources.c' -c -o 'objects/0056a6979356caf5fb6fd5493874bbd6.o'
printf "Compiling 'src/napc-rand-source/public/get_random_bit.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/public/get_random_bit.c' -c -o 'objects/964e0d2a74b15a9e2ab2d5a41ab1063a.o'
printf "Compiling 'src/napc-rand-source/public/get_random_bit_sources.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/public/get_random_bit_sources.c' -c -o 'objects/c4b3f2c7c3755f153459ec358b3359f4.o'
printf "Compiling 'src/napc-rand-source/public/get_random_byte.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-rand-source/public/get_random_byte.c' -c -o 'objects/3e823867d6b7975fb5b0ba3ef07d3844.o'
printf "Compiling 'src/napc-serial/HAL/linux/HAL_napc_initSerial.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/HAL/linux/HAL_napc_initSerial.c' -c -o 'objects/693f3d6fc36ea66a40e07f4384d73b14.o'
printf "Compiling 'src/napc-serial/HAL/linux/HAL_napc_putc.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/HAL/linux/HAL_napc_putc.c' -c -o 'objects/4380f491f90812d032c5ac3a30d0135a.o'
printf "Compiling 'src/napc-serial/HAL/linux/HAL_napc_puts.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/HAL/linux/HAL_napc_puts.c' -c -o 'objects/f39b09120b8fe76c3dbeab832cccc4c3.o'
printf "Compiling 'src/napc-serial/_private/_vars.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/_private/_vars.c' -c -o 'objects/d165b0d7bc832776972f495245d1f9a2.o'
printf "Compiling 'src/napc-serial/public/mute.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/public/mute.c' -c -o 'objects/fc86af89cdc760b11c2aefa8dcdcc64b.o'
printf "Compiling 'src/napc-serial/public/printf.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/public/printf.c' -c -o 'objects/9637153c9b1b0e737e89cfeb162857df.o'
printf "Compiling 'src/napc-serial/public/putc.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/public/putc.c' -c -o 'objects/e4e465ca5e1b078e546e770836c0638a.o'
printf "Compiling 'src/napc-serial/public/puts.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/public/puts.c' -c -o 'objects/b6897b1866d01fd8922cd381800507a4.o'
printf "Compiling 'src/napc-serial/public/unmute.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-serial/public/unmute.c' -c -o 'objects/66bef9735483b7effb5f8c8c3e012c25.o'
printf "Compiling 'src/napc-time/HAL/linux/HAL_napc_getTimeSinceBoot.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-time/HAL/linux/HAL_napc_getTimeSinceBoot.c' -c -o 'objects/ba586559524edfa87ff312a6fd6bbb83.o'
printf "Compiling 'src/napc-time/HAL/linux/HAL_napc_initTime.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-time/HAL/linux/HAL_napc_initTime.c' -c -o 'objects/20705124181e75a482fa9bd137f5b241.o'
printf "Compiling 'src/napc-time/public/get_time_since_boot.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-time/public/get_time_since_boot.c' -c -o 'objects/0ac3c1b92dacd1b568f8505e4203fec1.o'
printf "Compiling 'src/napc-time/public/get_time_since_boot_hr.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-time/public/get_time_since_boot_hr.c' -c -o 'objects/ea0ca8c3b67dbbddd386c9a695987503.o'
printf "Compiling 'src/napc-utils/public/memeql.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/memeql.c' -c -o 'objects/cd1c75b5cac9de6de367a1a03e642cb2.o'
printf "Compiling 'src/napc-utils/public/mzero.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/mzero.c' -c -o 'objects/a5efb4e8bed1e6456331234e3fc5a32d.o'
printf "Compiling 'src/napc-utils/public/snprintf.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/snprintf.c' -c -o 'objects/876dd9a38380cb3232b8eba96e03c364.o'
printf "Compiling 'src/napc-utils/public/streql.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/streql.c' -c -o 'objects/3f3fc6ba74734efd86da5581f24dcfe5.o'
printf "Compiling 'src/napc-utils/public/streqli.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/streqli.c' -c -o 'objects/a5d0d786444999f99af820a55a76a881.o'
printf "Compiling 'src/napc-utils/public/strlen.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/strlen.c' -c -o 'objects/35fd83988b80fffad453afe21bfcd3ab.o'
printf "Compiling 'src/napc-utils/public/strncpy.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/strncpy.c' -c -o 'objects/eb19bbfe490df82736d003f175b2d365.o'
printf "Compiling 'src/napc-utils/public/vsnprintf.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/napc-utils/public/vsnprintf.c' -c -o 'objects/bed842299b070ab9e98650c43628e650.o'
printf "Compiling 'src/testing.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/testing.c' -c -o 'objects/b171e33e80cefea620d8fd65d406f6a2.o'
printf "Compiling 'src/version.c'\n"
gcc -Wall -Wpedantic -Wextra -Wno-gnu-zero-variadic-macro-arguments -Werror -I./src 'src/version.c' -c -o 'objects/18af9f096c190ecee96547eb7f1f3bc1.o'
printf "Linking objects/f0c1e9478fd1b501c0ff9088e74e06e3.o\n"
ar rcs libnapc.a objects/f0c1e9478fd1b501c0ff9088e74e06e3.o
printf "Linking objects/0dea1f58855f47f87c3d7be241fe732c.o\n"
ar rcs libnapc.a objects/0dea1f58855f47f87c3d7be241fe732c.o
printf "Linking objects/cc7fc6d681341db592b4f8b8bef35974.o\n"
ar rcs libnapc.a objects/cc7fc6d681341db592b4f8b8bef35974.o
printf "Linking objects/8c362cdf6ec5d10138a300568358d553.o\n"
ar rcs libnapc.a objects/8c362cdf6ec5d10138a300568358d553.o
printf "Linking objects/801f8d70eec28113674ac2e003640cc6.o\n"
ar rcs libnapc.a objects/801f8d70eec28113674ac2e003640cc6.o
printf "Linking objects/e2176f7324d65ba2f9d645eebd049f8c.o\n"
ar rcs libnapc.a objects/e2176f7324d65ba2f9d645eebd049f8c.o
printf "Linking objects/9d4dbcabf309466bcf3f52f549789af5.o\n"
ar rcs libnapc.a objects/9d4dbcabf309466bcf3f52f549789af5.o
printf "Linking objects/1dd0d4e445b5a339a7f14d7fa1c75c0d.o\n"
ar rcs libnapc.a objects/1dd0d4e445b5a339a7f14d7fa1c75c0d.o
printf "Linking objects/d3408824f4818b132ad940cab6bb9f2c.o\n"
ar rcs libnapc.a objects/d3408824f4818b132ad940cab6bb9f2c.o
printf "Linking objects/0b93c770ecf98e6500c7d0f58a42a643.o\n"
ar rcs libnapc.a objects/0b93c770ecf98e6500c7d0f58a42a643.o
printf "Linking objects/7b238616039459e347afc2260d6f5514.o\n"
ar rcs libnapc.a objects/7b238616039459e347afc2260d6f5514.o
printf "Linking objects/7755b6a970d034f95dc03b49fe7b9ca3.o\n"
ar rcs libnapc.a objects/7755b6a970d034f95dc03b49fe7b9ca3.o
printf "Linking objects/5ebd9a9971f00260cc19b74345cce40f.o\n"
ar rcs libnapc.a objects/5ebd9a9971f00260cc19b74345cce40f.o
printf "Linking objects/fb94bf24f38b1724df83219d15181090.o\n"
ar rcs libnapc.a objects/fb94bf24f38b1724df83219d15181090.o
printf "Linking objects/0c3ff27b39e9e91af119ddf19a4651a5.o\n"
ar rcs libnapc.a objects/0c3ff27b39e9e91af119ddf19a4651a5.o
printf "Linking objects/992fb6a72a2244267970ed92bbbe9010.o\n"
ar rcs libnapc.a objects/992fb6a72a2244267970ed92bbbe9010.o
printf "Linking objects/e4836d19ff94dbae597a0daf8f475352.o\n"
ar rcs libnapc.a objects/e4836d19ff94dbae597a0daf8f475352.o
printf "Linking objects/173f9c58af9ba3f56caa123cb1a547dd.o\n"
ar rcs libnapc.a objects/173f9c58af9ba3f56caa123cb1a547dd.o
printf "Linking objects/0c34cf8909bfea60a0c497dea7faeef0.o\n"
ar rcs libnapc.a objects/0c34cf8909bfea60a0c497dea7faeef0.o
printf "Linking objects/c064fe1619a521af4b8ca04d40d2b07d.o\n"
ar rcs libnapc.a objects/c064fe1619a521af4b8ca04d40d2b07d.o
printf "Linking objects/fa4c895ecb1ce776981065260ca6b9a1.o\n"
ar rcs libnapc.a objects/fa4c895ecb1ce776981065260ca6b9a1.o
printf "Linking objects/06978da0239ef0d1a2c0e9f27947d45f.o\n"
ar rcs libnapc.a objects/06978da0239ef0d1a2c0e9f27947d45f.o
printf "Linking objects/3d07209759b511a6e9f38a602a455c21.o\n"
ar rcs libnapc.a objects/3d07209759b511a6e9f38a602a455c21.o
printf "Linking objects/65e8872a34b860a617ee11045844bf87.o\n"
ar rcs libnapc.a objects/65e8872a34b860a617ee11045844bf87.o
printf "Linking objects/f35c51b7b83ca91a4cc5b752c1e8162b.o\n"
ar rcs libnapc.a objects/f35c51b7b83ca91a4cc5b752c1e8162b.o
printf "Linking objects/58f3aa24e0ae90ddbd6f09306601057d.o\n"
ar rcs libnapc.a objects/58f3aa24e0ae90ddbd6f09306601057d.o
printf "Linking objects/5e479ce09e5fed21c489237b6637d8d9.o\n"
ar rcs libnapc.a objects/5e479ce09e5fed21c489237b6637d8d9.o
printf "Linking objects/b4dd9abb0c051cb171587a596b102aff.o\n"
ar rcs libnapc.a objects/b4dd9abb0c051cb171587a596b102aff.o
printf "Linking objects/7988957087dec554f6ab05a70a995d1a.o\n"
ar rcs libnapc.a objects/7988957087dec554f6ab05a70a995d1a.o
printf "Linking objects/eb2026e9dca03d5b5638b529944a76af.o\n"
ar rcs libnapc.a objects/eb2026e9dca03d5b5638b529944a76af.o
printf "Linking objects/49fc0a00e7c6ee41c57fcd6766dcd479.o\n"
ar rcs libnapc.a objects/49fc0a00e7c6ee41c57fcd6766dcd479.o
printf "Linking objects/0dce8841c063dc950882e531a5a4022d.o\n"
ar rcs libnapc.a objects/0dce8841c063dc950882e531a5a4022d.o
printf "Linking objects/1d7d84a9894049aff5e65e22d254dbc1.o\n"
ar rcs libnapc.a objects/1d7d84a9894049aff5e65e22d254dbc1.o
printf "Linking objects/bdb22ea809d4db3e72647650314443e4.o\n"
ar rcs libnapc.a objects/bdb22ea809d4db3e72647650314443e4.o
printf "Linking objects/9553bb4290c4cb909a9e9436f22f5510.o\n"
ar rcs libnapc.a objects/9553bb4290c4cb909a9e9436f22f5510.o
printf "Linking objects/23e173b33e7b162724631e5208bd7ab0.o\n"
ar rcs libnapc.a objects/23e173b33e7b162724631e5208bd7ab0.o
printf "Linking objects/97401f6515f6f943e74df7b7e7ae199a.o\n"
ar rcs libnapc.a objects/97401f6515f6f943e74df7b7e7ae199a.o
printf "Linking objects/c3629a5bc1d5c4bb7b32a5533e5bb4e5.o\n"
ar rcs libnapc.a objects/c3629a5bc1d5c4bb7b32a5533e5bb4e5.o
printf "Linking objects/56bbf920e74443ddba5bb05587f6f279.o\n"
ar rcs libnapc.a objects/56bbf920e74443ddba5bb05587f6f279.o
printf "Linking objects/5b8c0e82eb21337e5b5338bcd8f41849.o\n"
ar rcs libnapc.a objects/5b8c0e82eb21337e5b5338bcd8f41849.o
printf "Linking objects/968e6a6a99d47943d958fbd4dce9688f.o\n"
ar rcs libnapc.a objects/968e6a6a99d47943d958fbd4dce9688f.o
printf "Linking objects/31fefa2beace6f67f2d8cfb7cee32c91.o\n"
ar rcs libnapc.a objects/31fefa2beace6f67f2d8cfb7cee32c91.o
printf "Linking objects/a995c48c8a26a898ba3915e90d5e2564.o\n"
ar rcs libnapc.a objects/a995c48c8a26a898ba3915e90d5e2564.o
printf "Linking objects/20a54bbbe7eea39924c632e05fcea0f6.o\n"
ar rcs libnapc.a objects/20a54bbbe7eea39924c632e05fcea0f6.o
printf "Linking objects/678ce28d56d83305810cceaccd0f0047.o\n"
ar rcs libnapc.a objects/678ce28d56d83305810cceaccd0f0047.o
printf "Linking objects/34867fad559a631092bcf236a5fd2f83.o\n"
ar rcs libnapc.a objects/34867fad559a631092bcf236a5fd2f83.o
printf "Linking objects/0ef1e95523c2faa156ea3b53aad7d141.o\n"
ar rcs libnapc.a objects/0ef1e95523c2faa156ea3b53aad7d141.o
printf "Linking objects/387791dec2f998db7353761cfb77e6a2.o\n"
ar rcs libnapc.a objects/387791dec2f998db7353761cfb77e6a2.o
printf "Linking objects/19a2e7c7116d036716a22b2e56fe755a.o\n"
ar rcs libnapc.a objects/19a2e7c7116d036716a22b2e56fe755a.o
printf "Linking objects/1fa60672170db08f61d436af24b0f460.o\n"
ar rcs libnapc.a objects/1fa60672170db08f61d436af24b0f460.o
printf "Linking objects/24b0829608aba80882101defec9e49e3.o\n"
ar rcs libnapc.a objects/24b0829608aba80882101defec9e49e3.o
printf "Linking objects/e568fa11961b4942b1e7b55bb76d38f9.o\n"
ar rcs libnapc.a objects/e568fa11961b4942b1e7b55bb76d38f9.o
printf "Linking objects/72cfdf4e2383395259996777b7405b92.o\n"
ar rcs libnapc.a objects/72cfdf4e2383395259996777b7405b92.o
printf "Linking objects/a7fa54bbfd454c26202763b328f8d98f.o\n"
ar rcs libnapc.a objects/a7fa54bbfd454c26202763b328f8d98f.o
printf "Linking objects/613e2097b6a4748fadfe466552e59d86.o\n"
ar rcs libnapc.a objects/613e2097b6a4748fadfe466552e59d86.o
printf "Linking objects/f137822f60da332541efba34ec6363ac.o\n"
ar rcs libnapc.a objects/f137822f60da332541efba34ec6363ac.o
printf "Linking objects/4b5cdc6dcd239ff3f9d0753d410df9e6.o\n"
ar rcs libnapc.a objects/4b5cdc6dcd239ff3f9d0753d410df9e6.o
printf "Linking objects/9e0bcfa6bd04893c785600a642d41a88.o\n"
ar rcs libnapc.a objects/9e0bcfa6bd04893c785600a642d41a88.o
printf "Linking objects/4a53d9e1e21b899a255881a73768ffaa.o\n"
ar rcs libnapc.a objects/4a53d9e1e21b899a255881a73768ffaa.o
printf "Linking objects/5a86829ed07f0edd56be93bafc9cb19b.o\n"
ar rcs libnapc.a objects/5a86829ed07f0edd56be93bafc9cb19b.o
printf "Linking objects/55b651dce79b96548df33274a61362e2.o\n"
ar rcs libnapc.a objects/55b651dce79b96548df33274a61362e2.o
printf "Linking objects/26286fde75f9f3bebea349fccaf9a146.o\n"
ar rcs libnapc.a objects/26286fde75f9f3bebea349fccaf9a146.o
printf "Linking objects/3781012fd43ef4a817c8e18917e6b1fb.o\n"
ar rcs libnapc.a objects/3781012fd43ef4a817c8e18917e6b1fb.o
printf "Linking objects/d07519d265b02e16d4548e35a58f733a.o\n"
ar rcs libnapc.a objects/d07519d265b02e16d4548e35a58f733a.o
printf "Linking objects/eaeffe76b197154cf60a6ac1de10da6e.o\n"
ar rcs libnapc.a objects/eaeffe76b197154cf60a6ac1de10da6e.o
printf "Linking objects/e6903ab89dbd5cc18b03804ef996c12b.o\n"
ar rcs libnapc.a objects/e6903ab89dbd5cc18b03804ef996c12b.o
printf "Linking objects/dba50f1c21fa233b6412d954b7f934a0.o\n"
ar rcs libnapc.a objects/dba50f1c21fa233b6412d954b7f934a0.o
printf "Linking objects/495d341d5e1c54121af132612b0d5b9b.o\n"
ar rcs libnapc.a objects/495d341d5e1c54121af132612b0d5b9b.o
printf "Linking objects/f9025d4b3d0bbcdef6f74831ca588bf6.o\n"
ar rcs libnapc.a objects/f9025d4b3d0bbcdef6f74831ca588bf6.o
printf "Linking objects/3950844ff4662d44168e6c14fefde64c.o\n"
ar rcs libnapc.a objects/3950844ff4662d44168e6c14fefde64c.o
printf "Linking objects/d95a6cf2473af4c3ddc55e8baa261adf.o\n"
ar rcs libnapc.a objects/d95a6cf2473af4c3ddc55e8baa261adf.o
printf "Linking objects/fcc94430e1ab4ace1ce3ad0875615afb.o\n"
ar rcs libnapc.a objects/fcc94430e1ab4ace1ce3ad0875615afb.o
printf "Linking objects/969f6ab7fdb8b3f3c5d41e35e48e45fb.o\n"
ar rcs libnapc.a objects/969f6ab7fdb8b3f3c5d41e35e48e45fb.o
printf "Linking objects/8a9543a41aa9d5a1284355dc9d63a414.o\n"
ar rcs libnapc.a objects/8a9543a41aa9d5a1284355dc9d63a414.o
printf "Linking objects/3ea5ee4276d929230519b9536c316776.o\n"
ar rcs libnapc.a objects/3ea5ee4276d929230519b9536c316776.o
printf "Linking objects/c70392bf8845344ba6a2cd81d6b079d7.o\n"
ar rcs libnapc.a objects/c70392bf8845344ba6a2cd81d6b079d7.o
printf "Linking objects/a67b7919fcaab21f3c74090b9a3a3212.o\n"
ar rcs libnapc.a objects/a67b7919fcaab21f3c74090b9a3a3212.o
printf "Linking objects/c6e7b47cb21d48aa15be786355628122.o\n"
ar rcs libnapc.a objects/c6e7b47cb21d48aa15be786355628122.o
printf "Linking objects/e739e7e3f5cb7759fd35608d649de312.o\n"
ar rcs libnapc.a objects/e739e7e3f5cb7759fd35608d649de312.o
printf "Linking objects/ac9be2c44b2c14b9153f63237e19464a.o\n"
ar rcs libnapc.a objects/ac9be2c44b2c14b9153f63237e19464a.o
printf "Linking objects/0858c9d1a17009b0f876f475280b4ed9.o\n"
ar rcs libnapc.a objects/0858c9d1a17009b0f876f475280b4ed9.o
printf "Linking objects/2647aea7a09dac4139b1dd87572ff76f.o\n"
ar rcs libnapc.a objects/2647aea7a09dac4139b1dd87572ff76f.o
printf "Linking objects/d599b6c1c80be9ff74bdd55a5d43d9cc.o\n"
ar rcs libnapc.a objects/d599b6c1c80be9ff74bdd55a5d43d9cc.o
printf "Linking objects/af9e404d0e398f45c14553e8313048df.o\n"
ar rcs libnapc.a objects/af9e404d0e398f45c14553e8313048df.o
printf "Linking objects/0284afd5e58238c74ac45e666af32f26.o\n"
ar rcs libnapc.a objects/0284afd5e58238c74ac45e666af32f26.o
printf "Linking objects/b5257114f3daa14a41f447ebcd33fc47.o\n"
ar rcs libnapc.a objects/b5257114f3daa14a41f447ebcd33fc47.o
printf "Linking objects/7e57453291094f8d9cfac254c92be0ad.o\n"
ar rcs libnapc.a objects/7e57453291094f8d9cfac254c92be0ad.o
printf "Linking objects/6c32cd6a967751449ca1fb3a7c8d93b3.o\n"
ar rcs libnapc.a objects/6c32cd6a967751449ca1fb3a7c8d93b3.o
printf "Linking objects/c3a1dcf5c0ead6208bfd9dc9569d01a9.o\n"
ar rcs libnapc.a objects/c3a1dcf5c0ead6208bfd9dc9569d01a9.o
printf "Linking objects/5a467e95aa379170e578ba15af03f914.o\n"
ar rcs libnapc.a objects/5a467e95aa379170e578ba15af03f914.o
printf "Linking objects/c2330b50cdb3470408631b68899552f3.o\n"
ar rcs libnapc.a objects/c2330b50cdb3470408631b68899552f3.o
printf "Linking objects/688782fb3aaa836d97dce5347334e5cd.o\n"
ar rcs libnapc.a objects/688782fb3aaa836d97dce5347334e5cd.o
printf "Linking objects/d16d519b30a9a99e2580850eba8dc9df.o\n"
ar rcs libnapc.a objects/d16d519b30a9a99e2580850eba8dc9df.o
printf "Linking objects/2921edcda390fa435733bf607b8a5921.o\n"
ar rcs libnapc.a objects/2921edcda390fa435733bf607b8a5921.o
printf "Linking objects/a22022a6f39e1ad493481c092fe6ab47.o\n"
ar rcs libnapc.a objects/a22022a6f39e1ad493481c092fe6ab47.o
printf "Linking objects/dadc73df3bde9b4d726ad953afec4744.o\n"
ar rcs libnapc.a objects/dadc73df3bde9b4d726ad953afec4744.o
printf "Linking objects/13cb2b8ed70187216872fb8c7b26d838.o\n"
ar rcs libnapc.a objects/13cb2b8ed70187216872fb8c7b26d838.o
printf "Linking objects/7ce426e8a1031ce5c06c7447fc459ec7.o\n"
ar rcs libnapc.a objects/7ce426e8a1031ce5c06c7447fc459ec7.o
printf "Linking objects/f63a51d257ebc3e78c008d2e95a321d8.o\n"
ar rcs libnapc.a objects/f63a51d257ebc3e78c008d2e95a321d8.o
printf "Linking objects/34b17a04dd45d54cb8c3916f4fe0e641.o\n"
ar rcs libnapc.a objects/34b17a04dd45d54cb8c3916f4fe0e641.o
printf "Linking objects/4f5a3623f526af1a4988837c376a272d.o\n"
ar rcs libnapc.a objects/4f5a3623f526af1a4988837c376a272d.o
printf "Linking objects/307de34d781c47607327d68ea91c8be8.o\n"
ar rcs libnapc.a objects/307de34d781c47607327d68ea91c8be8.o
printf "Linking objects/36a3c9a7ccbb671510945c76cd5208d2.o\n"
ar rcs libnapc.a objects/36a3c9a7ccbb671510945c76cd5208d2.o
printf "Linking objects/b16614409970bd0e512f160271dddda9.o\n"
ar rcs libnapc.a objects/b16614409970bd0e512f160271dddda9.o
printf "Linking objects/b9cb209ba2bf8531d3245d31fbdde61d.o\n"
ar rcs libnapc.a objects/b9cb209ba2bf8531d3245d31fbdde61d.o
printf "Linking objects/08d05258ebc9028b1c6c53d3b8363579.o\n"
ar rcs libnapc.a objects/08d05258ebc9028b1c6c53d3b8363579.o
printf "Linking objects/c533140b78bc82d9c0e349dc802e5fd5.o\n"
ar rcs libnapc.a objects/c533140b78bc82d9c0e349dc802e5fd5.o
printf "Linking objects/38dfafe1edb7d74d619d441578561125.o\n"
ar rcs libnapc.a objects/38dfafe1edb7d74d619d441578561125.o
printf "Linking objects/a7d68cd3f0d8083d3c56685429455636.o\n"
ar rcs libnapc.a objects/a7d68cd3f0d8083d3c56685429455636.o
printf "Linking objects/02f89ea095d5eb104b97a3be56f0a987.o\n"
ar rcs libnapc.a objects/02f89ea095d5eb104b97a3be56f0a987.o
printf "Linking objects/e8169df9bc2b1aefa5895f4853c3eaea.o\n"
ar rcs libnapc.a objects/e8169df9bc2b1aefa5895f4853c3eaea.o
printf "Linking objects/cf1e83a5e23e26ff5ac1c935d7df461f.o\n"
ar rcs libnapc.a objects/cf1e83a5e23e26ff5ac1c935d7df461f.o
printf "Linking objects/049d0eb5f82278f62ddbcf9b40628f6e.o\n"
ar rcs libnapc.a objects/049d0eb5f82278f62ddbcf9b40628f6e.o
printf "Linking objects/7337d2635388018a0b44c3370c968ec6.o\n"
ar rcs libnapc.a objects/7337d2635388018a0b44c3370c968ec6.o
printf "Linking objects/a002bc8afebd1d99dfde28ab082aabe3.o\n"
ar rcs libnapc.a objects/a002bc8afebd1d99dfde28ab082aabe3.o
printf "Linking objects/30a9de55714df5086fca2ccd0efb98a6.o\n"
ar rcs libnapc.a objects/30a9de55714df5086fca2ccd0efb98a6.o
printf "Linking objects/42132ad0b9493b24f406df7e83c714f6.o\n"
ar rcs libnapc.a objects/42132ad0b9493b24f406df7e83c714f6.o
printf "Linking objects/a5aa41106e965ad1247cd89e1280754f.o\n"
ar rcs libnapc.a objects/a5aa41106e965ad1247cd89e1280754f.o
printf "Linking objects/5ecce97de42eec974d8480e4bec57ecf.o\n"
ar rcs libnapc.a objects/5ecce97de42eec974d8480e4bec57ecf.o
printf "Linking objects/765db23901898439cc92f529ed5f1dee.o\n"
ar rcs libnapc.a objects/765db23901898439cc92f529ed5f1dee.o
printf "Linking objects/5b7e9d1b896972dd8213ec515dc977cf.o\n"
ar rcs libnapc.a objects/5b7e9d1b896972dd8213ec515dc977cf.o
printf "Linking objects/951a071ee3f889c78c0d473acab5c936.o\n"
ar rcs libnapc.a objects/951a071ee3f889c78c0d473acab5c936.o
printf "Linking objects/0285f884ff0847e252eb20040ce98bd4.o\n"
ar rcs libnapc.a objects/0285f884ff0847e252eb20040ce98bd4.o
printf "Linking objects/3f2e26bd50bf05e7322ca12817f0861f.o\n"
ar rcs libnapc.a objects/3f2e26bd50bf05e7322ca12817f0861f.o
printf "Linking objects/81d7bcfc3b5c9d08abbb19dab64387ac.o\n"
ar rcs libnapc.a objects/81d7bcfc3b5c9d08abbb19dab64387ac.o
printf "Linking objects/f3d5d733e3f2c1449c1b72d39784c860.o\n"
ar rcs libnapc.a objects/f3d5d733e3f2c1449c1b72d39784c860.o
printf "Linking objects/73d90425a3e329480f061f44f1f795c2.o\n"
ar rcs libnapc.a objects/73d90425a3e329480f061f44f1f795c2.o
printf "Linking objects/1d51b0269d61faccf302336cd23608b8.o\n"
ar rcs libnapc.a objects/1d51b0269d61faccf302336cd23608b8.o
printf "Linking objects/ed96683d2cea2271587e5aeace96a141.o\n"
ar rcs libnapc.a objects/ed96683d2cea2271587e5aeace96a141.o
printf "Linking objects/9e4488dbd5c96fbb22449c4a625a52a6.o\n"
ar rcs libnapc.a objects/9e4488dbd5c96fbb22449c4a625a52a6.o
printf "Linking objects/ec0c254f6dea7a9ade2ebe5310f0e657.o\n"
ar rcs libnapc.a objects/ec0c254f6dea7a9ade2ebe5310f0e657.o
printf "Linking objects/5dc2d835d1fed28972e99133cc98d0f4.o\n"
ar rcs libnapc.a objects/5dc2d835d1fed28972e99133cc98d0f4.o
printf "Linking objects/58c2877115226644de88342bb40ab54c.o\n"
ar rcs libnapc.a objects/58c2877115226644de88342bb40ab54c.o
printf "Linking objects/4b7bde1f7e1720e3598576c16190ebae.o\n"
ar rcs libnapc.a objects/4b7bde1f7e1720e3598576c16190ebae.o
printf "Linking objects/5ca47c5219740c0018b74fa19edd9c60.o\n"
ar rcs libnapc.a objects/5ca47c5219740c0018b74fa19edd9c60.o
printf "Linking objects/d037b4438e99aae313f2a634afc70dc8.o\n"
ar rcs libnapc.a objects/d037b4438e99aae313f2a634afc70dc8.o
printf "Linking objects/b3d1ea787b134c1f369c935f368a326e.o\n"
ar rcs libnapc.a objects/b3d1ea787b134c1f369c935f368a326e.o
printf "Linking objects/783b6da28ff7642520f7a00e936a1a8b.o\n"
ar rcs libnapc.a objects/783b6da28ff7642520f7a00e936a1a8b.o
printf "Linking objects/c47bc777f8729e32af68b6160a77e7ac.o\n"
ar rcs libnapc.a objects/c47bc777f8729e32af68b6160a77e7ac.o
printf "Linking objects/29b6f29917747c47e65885e35373f6b8.o\n"
ar rcs libnapc.a objects/29b6f29917747c47e65885e35373f6b8.o
printf "Linking objects/7ff281c7ac52ae8843e5fbbb0ada4118.o\n"
ar rcs libnapc.a objects/7ff281c7ac52ae8843e5fbbb0ada4118.o
printf "Linking objects/950b0e63c253533dfaecf94db12262f9.o\n"
ar rcs libnapc.a objects/950b0e63c253533dfaecf94db12262f9.o
printf "Linking objects/0455fc0bff05757be88cacb776b495b6.o\n"
ar rcs libnapc.a objects/0455fc0bff05757be88cacb776b495b6.o
printf "Linking objects/5d8d34d3af4dbbd5fa2e96d608bd9420.o\n"
ar rcs libnapc.a objects/5d8d34d3af4dbbd5fa2e96d608bd9420.o
printf "Linking objects/3e296f966f2a87dd46c8450fb3cf2a63.o\n"
ar rcs libnapc.a objects/3e296f966f2a87dd46c8450fb3cf2a63.o
printf "Linking objects/617768696466e9a69455fdcc598ab2a2.o\n"
ar rcs libnapc.a objects/617768696466e9a69455fdcc598ab2a2.o
printf "Linking objects/c0b84f4e2af8417ba9577b86b0754dec.o\n"
ar rcs libnapc.a objects/c0b84f4e2af8417ba9577b86b0754dec.o
printf "Linking objects/cf8e244eb47140dff9501d9aca91c43c.o\n"
ar rcs libnapc.a objects/cf8e244eb47140dff9501d9aca91c43c.o
printf "Linking objects/37d1d345e72ed4a042cce3a234554332.o\n"
ar rcs libnapc.a objects/37d1d345e72ed4a042cce3a234554332.o
printf "Linking objects/288430c4785aede8488cc248fc6ca431.o\n"
ar rcs libnapc.a objects/288430c4785aede8488cc248fc6ca431.o
printf "Linking objects/c9f250069c71198216cd3f48ee9d1a5e.o\n"
ar rcs libnapc.a objects/c9f250069c71198216cd3f48ee9d1a5e.o
printf "Linking objects/8d6b818437d2771662246ca64e357ac5.o\n"
ar rcs libnapc.a objects/8d6b818437d2771662246ca64e357ac5.o
printf "Linking objects/c570e238969bf7336acfbf258ff851f0.o\n"
ar rcs libnapc.a objects/c570e238969bf7336acfbf258ff851f0.o
printf "Linking objects/7ab2543b860572e95f578bc1d918856e.o\n"
ar rcs libnapc.a objects/7ab2543b860572e95f578bc1d918856e.o
printf "Linking objects/75706a72931858748f485c90ce3c211e.o\n"
ar rcs libnapc.a objects/75706a72931858748f485c90ce3c211e.o
printf "Linking objects/44aad1e40bdb89bc995a037259f233fe.o\n"
ar rcs libnapc.a objects/44aad1e40bdb89bc995a037259f233fe.o
printf "Linking objects/3c857d82684a786d92fc4b11abebae41.o\n"
ar rcs libnapc.a objects/3c857d82684a786d92fc4b11abebae41.o
printf "Linking objects/21207a2bcc0aa597b5ea484262b4c7bb.o\n"
ar rcs libnapc.a objects/21207a2bcc0aa597b5ea484262b4c7bb.o
printf "Linking objects/8f7c384531570e47fc368313f8c338a2.o\n"
ar rcs libnapc.a objects/8f7c384531570e47fc368313f8c338a2.o
printf "Linking objects/50066eba7b20fd73db5c0640800536a9.o\n"
ar rcs libnapc.a objects/50066eba7b20fd73db5c0640800536a9.o
printf "Linking objects/937ba56a810a474acac7b7f0b9ebea56.o\n"
ar rcs libnapc.a objects/937ba56a810a474acac7b7f0b9ebea56.o
printf "Linking objects/39a6f21e4f28e8e8b86494d97225e6e9.o\n"
ar rcs libnapc.a objects/39a6f21e4f28e8e8b86494d97225e6e9.o
printf "Linking objects/6a352a73a928d9498fe2d90fb59d87c9.o\n"
ar rcs libnapc.a objects/6a352a73a928d9498fe2d90fb59d87c9.o
printf "Linking objects/0c6e60a278bcff080af3f5c842cdb1ca.o\n"
ar rcs libnapc.a objects/0c6e60a278bcff080af3f5c842cdb1ca.o
printf "Linking objects/4d58fabe889609034688622ac9c2e962.o\n"
ar rcs libnapc.a objects/4d58fabe889609034688622ac9c2e962.o
printf "Linking objects/51360b5823f70cc050f1ce4024b4e2a4.o\n"
ar rcs libnapc.a objects/51360b5823f70cc050f1ce4024b4e2a4.o
printf "Linking objects/4905aa472b4a8853f7d93ca6ed2abda6.o\n"
ar rcs libnapc.a objects/4905aa472b4a8853f7d93ca6ed2abda6.o
printf "Linking objects/29a14ffc459486750797cb6f510d2516.o\n"
ar rcs libnapc.a objects/29a14ffc459486750797cb6f510d2516.o
printf "Linking objects/3050ff50b8f4011af702b1c4dcd498bb.o\n"
ar rcs libnapc.a objects/3050ff50b8f4011af702b1c4dcd498bb.o
printf "Linking objects/29d5b96968ec4b151714f11a271be1d7.o\n"
ar rcs libnapc.a objects/29d5b96968ec4b151714f11a271be1d7.o
printf "Linking objects/d49055044a13bf9553bb5aed5e5471f4.o\n"
ar rcs libnapc.a objects/d49055044a13bf9553bb5aed5e5471f4.o
printf "Linking objects/7c048f796fc2dacbad806b6a71c7b7ec.o\n"
ar rcs libnapc.a objects/7c048f796fc2dacbad806b6a71c7b7ec.o
printf "Linking objects/a5d985d22b9fdb164ebd365528fc9634.o\n"
ar rcs libnapc.a objects/a5d985d22b9fdb164ebd365528fc9634.o
printf "Linking objects/761fc0085f14fc48ace696d1b37cefb1.o\n"
ar rcs libnapc.a objects/761fc0085f14fc48ace696d1b37cefb1.o
printf "Linking objects/a336efe424733c20cbdaafb19aaf6f4c.o\n"
ar rcs libnapc.a objects/a336efe424733c20cbdaafb19aaf6f4c.o
printf "Linking objects/5e14d455007f1c33cde181826ed5fcdb.o\n"
ar rcs libnapc.a objects/5e14d455007f1c33cde181826ed5fcdb.o
printf "Linking objects/cc377cdc895368b03cfaa9a142936f8e.o\n"
ar rcs libnapc.a objects/cc377cdc895368b03cfaa9a142936f8e.o
printf "Linking objects/2a166317d50541b5c8ca8814c35ee474.o\n"
ar rcs libnapc.a objects/2a166317d50541b5c8ca8814c35ee474.o
printf "Linking objects/b617500837103a249cf5e452f526f239.o\n"
ar rcs libnapc.a objects/b617500837103a249cf5e452f526f239.o
printf "Linking objects/6e3a9113ab04bfec83b53c0757befd27.o\n"
ar rcs libnapc.a objects/6e3a9113ab04bfec83b53c0757befd27.o
printf "Linking objects/d98e2c9ada9f8f819a87875105068f68.o\n"
ar rcs libnapc.a objects/d98e2c9ada9f8f819a87875105068f68.o
printf "Linking objects/49f00ecc59e7c3b5ad34e079cf00386e.o\n"
ar rcs libnapc.a objects/49f00ecc59e7c3b5ad34e079cf00386e.o
printf "Linking objects/5af9a082306bdfc7261495e4a7e30838.o\n"
ar rcs libnapc.a objects/5af9a082306bdfc7261495e4a7e30838.o
printf "Linking objects/dcae2f334ab418bb67497ab0e072c37e.o\n"
ar rcs libnapc.a objects/dcae2f334ab418bb67497ab0e072c37e.o
printf "Linking objects/28bd1a5ef42f2a05401a040a3f1b8338.o\n"
ar rcs libnapc.a objects/28bd1a5ef42f2a05401a040a3f1b8338.o
printf "Linking objects/a7b09421928f797c85a7d0597dfe7e6f.o\n"
ar rcs libnapc.a objects/a7b09421928f797c85a7d0597dfe7e6f.o
printf "Linking objects/10583c55bc98550db8e2e7e16524104a.o\n"
ar rcs libnapc.a objects/10583c55bc98550db8e2e7e16524104a.o
printf "Linking objects/6c27fbf4b959a33995258804fe21e5ec.o\n"
ar rcs libnapc.a objects/6c27fbf4b959a33995258804fe21e5ec.o
printf "Linking objects/ddbd069e8259acc872e4c931c85476ba.o\n"
ar rcs libnapc.a objects/ddbd069e8259acc872e4c931c85476ba.o
printf "Linking objects/ab607130c890c513b8b417c654923c90.o\n"
ar rcs libnapc.a objects/ab607130c890c513b8b417c654923c90.o
printf "Linking objects/0765e79eacbb196badab3c050abfa146.o\n"
ar rcs libnapc.a objects/0765e79eacbb196badab3c050abfa146.o
printf "Linking objects/8d8891418492bf66b95664d9d53a0cd3.o\n"
ar rcs libnapc.a objects/8d8891418492bf66b95664d9d53a0cd3.o
printf "Linking objects/84963e34d968a404b89b9aa719087d92.o\n"
ar rcs libnapc.a objects/84963e34d968a404b89b9aa719087d92.o
printf "Linking objects/6c1a061c0c651c6cf7534f5923f29bd3.o\n"
ar rcs libnapc.a objects/6c1a061c0c651c6cf7534f5923f29bd3.o
printf "Linking objects/2760c2a9d32d21e825145333fa34e333.o\n"
ar rcs libnapc.a objects/2760c2a9d32d21e825145333fa34e333.o
printf "Linking objects/6b4e0003f596a8f78825123c2bf40a9f.o\n"
ar rcs libnapc.a objects/6b4e0003f596a8f78825123c2bf40a9f.o
printf "Linking objects/104b3669bd9ed026fa704f7503ec31c9.o\n"
ar rcs libnapc.a objects/104b3669bd9ed026fa704f7503ec31c9.o
printf "Linking objects/a57b0446b322748bd157d4f013b38743.o\n"
ar rcs libnapc.a objects/a57b0446b322748bd157d4f013b38743.o
printf "Linking objects/bf1d7337f360163cd29f4f183d146371.o\n"
ar rcs libnapc.a objects/bf1d7337f360163cd29f4f183d146371.o
printf "Linking objects/3df9e0def99a65305b50862617081421.o\n"
ar rcs libnapc.a objects/3df9e0def99a65305b50862617081421.o
printf "Linking objects/ad8581024808b8bb7ecdb8bfa191df60.o\n"
ar rcs libnapc.a objects/ad8581024808b8bb7ecdb8bfa191df60.o
printf "Linking objects/7dd22eefbd3e5a60133ea97df87e7794.o\n"
ar rcs libnapc.a objects/7dd22eefbd3e5a60133ea97df87e7794.o
printf "Linking objects/5e9db0e93dbf6cd649387d2af319fb7f.o\n"
ar rcs libnapc.a objects/5e9db0e93dbf6cd649387d2af319fb7f.o
printf "Linking objects/3fb91227118e7cd8e427f485edbcd5ef.o\n"
ar rcs libnapc.a objects/3fb91227118e7cd8e427f485edbcd5ef.o
printf "Linking objects/a6c61ce893012e5e6c4ebb34ede9f65f.o\n"
ar rcs libnapc.a objects/a6c61ce893012e5e6c4ebb34ede9f65f.o
printf "Linking objects/558bb61ebb90b74006e06b7b793e36a0.o\n"
ar rcs libnapc.a objects/558bb61ebb90b74006e06b7b793e36a0.o
printf "Linking objects/91980ce79a09dda7e3c7ee11b8f59bd9.o\n"
ar rcs libnapc.a objects/91980ce79a09dda7e3c7ee11b8f59bd9.o
printf "Linking objects/ea9dac151b1a4b36b0cc3bb8373d6532.o\n"
ar rcs libnapc.a objects/ea9dac151b1a4b36b0cc3bb8373d6532.o
printf "Linking objects/e47063747e00382865fb592adc7c1ad4.o\n"
ar rcs libnapc.a objects/e47063747e00382865fb592adc7c1ad4.o
printf "Linking objects/2fd3351dca0bfed86f7635fa7cf646a6.o\n"
ar rcs libnapc.a objects/2fd3351dca0bfed86f7635fa7cf646a6.o
printf "Linking objects/2b71db954c41818dc2602034e80c52dc.o\n"
ar rcs libnapc.a objects/2b71db954c41818dc2602034e80c52dc.o
printf "Linking objects/50cdd3a8e8c0a45659907f0615098b95.o\n"
ar rcs libnapc.a objects/50cdd3a8e8c0a45659907f0615098b95.o
printf "Linking objects/8f826128bd184361a0a94c6ed920bb3f.o\n"
ar rcs libnapc.a objects/8f826128bd184361a0a94c6ed920bb3f.o
printf "Linking objects/d6a91a3583df08f13ba8ab9551323d68.o\n"
ar rcs libnapc.a objects/d6a91a3583df08f13ba8ab9551323d68.o
printf "Linking objects/6989c5a05bf02eed6e4b1bb76b318e3e.o\n"
ar rcs libnapc.a objects/6989c5a05bf02eed6e4b1bb76b318e3e.o
printf "Linking objects/2a4801d156e1c7109a59e9036988d60b.o\n"
ar rcs libnapc.a objects/2a4801d156e1c7109a59e9036988d60b.o
printf "Linking objects/23a8d3dc9039ac290c4ba59073e6b944.o\n"
ar rcs libnapc.a objects/23a8d3dc9039ac290c4ba59073e6b944.o
printf "Linking objects/7160fec9a58760aa3aeedcee9ddf6c4b.o\n"
ar rcs libnapc.a objects/7160fec9a58760aa3aeedcee9ddf6c4b.o
printf "Linking objects/d1f0867e029e4aef3cc8d67f86cf0436.o\n"
ar rcs libnapc.a objects/d1f0867e029e4aef3cc8d67f86cf0436.o
printf "Linking objects/ff72cf3e2890ba6c3025c4d8a4cb75d6.o\n"
ar rcs libnapc.a objects/ff72cf3e2890ba6c3025c4d8a4cb75d6.o
printf "Linking objects/3090a5584b6427e871d9ad30a6eed599.o\n"
ar rcs libnapc.a objects/3090a5584b6427e871d9ad30a6eed599.o
printf "Linking objects/c5b57295a0954a15684b91de761d9686.o\n"
ar rcs libnapc.a objects/c5b57295a0954a15684b91de761d9686.o
printf "Linking objects/da6d132fe39e83152d5eb260b0e51356.o\n"
ar rcs libnapc.a objects/da6d132fe39e83152d5eb260b0e51356.o
printf "Linking objects/47d2eb4a647c0927f5e3691c745f75e6.o\n"
ar rcs libnapc.a objects/47d2eb4a647c0927f5e3691c745f75e6.o
printf "Linking objects/de8e279fdb7720aeebfd274dba4cc78a.o\n"
ar rcs libnapc.a objects/de8e279fdb7720aeebfd274dba4cc78a.o
printf "Linking objects/e8bd909e096f62dae991ab10873b5e9b.o\n"
ar rcs libnapc.a objects/e8bd909e096f62dae991ab10873b5e9b.o
printf "Linking objects/d0d3634f19fcf114efacdb7e90ca0169.o\n"
ar rcs libnapc.a objects/d0d3634f19fcf114efacdb7e90ca0169.o
printf "Linking objects/5ed4f82059c9f5d7a996342dec68b2a8.o\n"
ar rcs libnapc.a objects/5ed4f82059c9f5d7a996342dec68b2a8.o
printf "Linking objects/92cc07797bd645b1e8bb6e145a5871e0.o\n"
ar rcs libnapc.a objects/92cc07797bd645b1e8bb6e145a5871e0.o
printf "Linking objects/41b78eccfac2b5a838f22926cc6872fd.o\n"
ar rcs libnapc.a objects/41b78eccfac2b5a838f22926cc6872fd.o
printf "Linking objects/146758d7ff009bdf759e0cfe3f76939c.o\n"
ar rcs libnapc.a objects/146758d7ff009bdf759e0cfe3f76939c.o
printf "Linking objects/81a3d74d1b15a1dd970ed24c355df596.o\n"
ar rcs libnapc.a objects/81a3d74d1b15a1dd970ed24c355df596.o
printf "Linking objects/35f5003726ddc1a56e270c318b1689d8.o\n"
ar rcs libnapc.a objects/35f5003726ddc1a56e270c318b1689d8.o
printf "Linking objects/c65fc71b4f9862d0962bce30c854a9b1.o\n"
ar rcs libnapc.a objects/c65fc71b4f9862d0962bce30c854a9b1.o
printf "Linking objects/29a1b2c88561feef758cf87bac8ae849.o\n"
ar rcs libnapc.a objects/29a1b2c88561feef758cf87bac8ae849.o
printf "Linking objects/0d9351237a27a85c701c55fd291ff18e.o\n"
ar rcs libnapc.a objects/0d9351237a27a85c701c55fd291ff18e.o
printf "Linking objects/0056a6979356caf5fb6fd5493874bbd6.o\n"
ar rcs libnapc.a objects/0056a6979356caf5fb6fd5493874bbd6.o
printf "Linking objects/964e0d2a74b15a9e2ab2d5a41ab1063a.o\n"
ar rcs libnapc.a objects/964e0d2a74b15a9e2ab2d5a41ab1063a.o
printf "Linking objects/c4b3f2c7c3755f153459ec358b3359f4.o\n"
ar rcs libnapc.a objects/c4b3f2c7c3755f153459ec358b3359f4.o
printf "Linking objects/3e823867d6b7975fb5b0ba3ef07d3844.o\n"
ar rcs libnapc.a objects/3e823867d6b7975fb5b0ba3ef07d3844.o
printf "Linking objects/693f3d6fc36ea66a40e07f4384d73b14.o\n"
ar rcs libnapc.a objects/693f3d6fc36ea66a40e07f4384d73b14.o
printf "Linking objects/4380f491f90812d032c5ac3a30d0135a.o\n"
ar rcs libnapc.a objects/4380f491f90812d032c5ac3a30d0135a.o
printf "Linking objects/f39b09120b8fe76c3dbeab832cccc4c3.o\n"
ar rcs libnapc.a objects/f39b09120b8fe76c3dbeab832cccc4c3.o
printf "Linking objects/d165b0d7bc832776972f495245d1f9a2.o\n"
ar rcs libnapc.a objects/d165b0d7bc832776972f495245d1f9a2.o
printf "Linking objects/fc86af89cdc760b11c2aefa8dcdcc64b.o\n"
ar rcs libnapc.a objects/fc86af89cdc760b11c2aefa8dcdcc64b.o
printf "Linking objects/9637153c9b1b0e737e89cfeb162857df.o\n"
ar rcs libnapc.a objects/9637153c9b1b0e737e89cfeb162857df.o
printf "Linking objects/e4e465ca5e1b078e546e770836c0638a.o\n"
ar rcs libnapc.a objects/e4e465ca5e1b078e546e770836c0638a.o
printf "Linking objects/b6897b1866d01fd8922cd381800507a4.o\n"
ar rcs libnapc.a objects/b6897b1866d01fd8922cd381800507a4.o
printf "Linking objects/66bef9735483b7effb5f8c8c3e012c25.o\n"
ar rcs libnapc.a objects/66bef9735483b7effb5f8c8c3e012c25.o
printf "Linking objects/ba586559524edfa87ff312a6fd6bbb83.o\n"
ar rcs libnapc.a objects/ba586559524edfa87ff312a6fd6bbb83.o
printf "Linking objects/20705124181e75a482fa9bd137f5b241.o\n"
ar rcs libnapc.a objects/20705124181e75a482fa9bd137f5b241.o
printf "Linking objects/0ac3c1b92dacd1b568f8505e4203fec1.o\n"
ar rcs libnapc.a objects/0ac3c1b92dacd1b568f8505e4203fec1.o
printf "Linking objects/ea0ca8c3b67dbbddd386c9a695987503.o\n"
ar rcs libnapc.a objects/ea0ca8c3b67dbbddd386c9a695987503.o
printf "Linking objects/cd1c75b5cac9de6de367a1a03e642cb2.o\n"
ar rcs libnapc.a objects/cd1c75b5cac9de6de367a1a03e642cb2.o
printf "Linking objects/a5efb4e8bed1e6456331234e3fc5a32d.o\n"
ar rcs libnapc.a objects/a5efb4e8bed1e6456331234e3fc5a32d.o
printf "Linking objects/876dd9a38380cb3232b8eba96e03c364.o\n"
ar rcs libnapc.a objects/876dd9a38380cb3232b8eba96e03c364.o
printf "Linking objects/3f3fc6ba74734efd86da5581f24dcfe5.o\n"
ar rcs libnapc.a objects/3f3fc6ba74734efd86da5581f24dcfe5.o
printf "Linking objects/a5d0d786444999f99af820a55a76a881.o\n"
ar rcs libnapc.a objects/a5d0d786444999f99af820a55a76a881.o
printf "Linking objects/35fd83988b80fffad453afe21bfcd3ab.o\n"
ar rcs libnapc.a objects/35fd83988b80fffad453afe21bfcd3ab.o
printf "Linking objects/eb19bbfe490df82736d003f175b2d365.o\n"
ar rcs libnapc.a objects/eb19bbfe490df82736d003f175b2d365.o
printf "Linking objects/bed842299b070ab9e98650c43628e650.o\n"
ar rcs libnapc.a objects/bed842299b070ab9e98650c43628e650.o
printf "Linking objects/b171e33e80cefea620d8fd65d406f6a2.o\n"
ar rcs libnapc.a objects/b171e33e80cefea620d8fd65d406f6a2.o
printf "Linking objects/18af9f096c190ecee96547eb7f1f3bc1.o\n"
ar rcs libnapc.a objects/18af9f096c190ecee96547eb7f1f3bc1.o
